﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class ARForwardTurnRightAction : OutputActionTimed
    {
        public ARForwardTurnRightAction(int milliseconds, string id) 
         :base(milliseconds, id)
        {

        }

        public override bool DoTimedLogic()
        {

            return true; 
        }
    }
}
