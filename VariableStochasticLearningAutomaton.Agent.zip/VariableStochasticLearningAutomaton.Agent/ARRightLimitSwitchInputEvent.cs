﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class ARRightLimitSwitchInputEvent : InputEvent
    {
        public ARRightLimitSwitchInputEvent(IEnumerable<OutputAction> pActionList, bool isMotivator = false, bool isSetFrameBoundaryEvent = false, bool doesSystemRespondToEvent = false) :
         base(pActionList, isMotivator , isSetFrameBoundaryEvent , doesSystemRespondToEvent )
        {

        }

        public override void SendDebugInfo(string start, string end)
        {
            //Console.WriteLine("Object:" + start + Name + " X=" + X + " Y=" + Y + " BX=" + BX + " BY=" + BY + " " + end);
        }

        public string Name { get; set; }

        public override bool IsMatch(InputEvent ev)
        {
            if (ev.GetType() == typeof(ARLeftLimitSwitchInputEvent))
            {
                return true;
            }

            return false;
        }

        bool _setValue = true;
        public void SetValue(bool value = false)
        {
            _setValue = value;
        }

        public override bool RunLogic()
        {
            if (_setValue == false)
                return false;
            else
            {
                _setValue = false;
                return true;
            }
        }

        public override bool IsSimilar(InputEvent ev)
        {
            if (this == ev)
                return true;
            else
                return false;
        }

    }
}
