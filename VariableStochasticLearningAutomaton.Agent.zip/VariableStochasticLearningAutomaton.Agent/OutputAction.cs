﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class OutputAction
    {

        protected DateTime _timeEnd;
        private int _milliseconds;

        public OutputAction(int milliseconds, string id)
        {
            _actionQueue = null ;
            Id = id; 
        }

        public bool OnStart()
        {
            _timeEnd = DateTime.Now.AddMilliseconds(_milliseconds);
            return true;
        }

        public bool DoTimedLogic()
        {

            return true;
        }


        public bool RunLogic()
        {
            if (DateTime.Now <= _timeEnd)
                return false;
            else
                return true;
        }

        public string Id { get; set; }

#region actionsqueue interface methods 
        protected List<OutputAction> _actionQueue ; // can run sub actions 
        public IEnumerable<OutputAction> GetActions()
        {
            return _actionQueue;
        }

        public void Add(OutputAction action)
        {
            if (_actionQueue == null)
                _actionQueue = new List<OutputAction>();

            _actionQueue.Add(action);
        }

        public void Remove(OutputAction action)
        {
            if (_actionQueue != null)
                _actionQueue.Remove(action);
        }
#endregion end actions interface methods 

        protected bool _isProcessing;
        protected bool _isDone; 
        
        public virtual bool Run()
        {
	        if ( _isProcessing == false) 
	        {
		        OnStart() ; 
		        _isProcessing = true ;
	        }

	        RunActionQueue();

	        if ( _isDone == true ) 
		        OnComplete() ;

            if (_isDone == true)
                return true;
            else
                return false; 
        }

        /// <summary>
        /// 
        /// </summary>

        public virtual bool OnComplete()
        {
            return true; 
        }

        /// <summary>
        ///  this method is called by infrastructure in case this action starts and then in the middle of its action
        /// another action is started because there is a more likely input "pattern" of events that have occurred
        /// 
        /// eg 
        /// event 1
        ///     event 1
        ///     event 2
        /// event 2
        /// event 3
        /// 
        /// 
        /// </summary>
        /// <returns></returns>
        public virtual bool CleanupAction()
        {
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool RunActionQueue()  // will run each action in queue in order until each IsDone() == true at which point it will mark
        {						// IsDone on this action == true and then call OnComplete() 
	        if (_actionQueue != null) 
	        {
		        bool allActionsDone = true ;  
		        for ( int index = 0 ; index < _actionQueue.Count() ; index ++ ) 
		        {
			        OutputAction pAction = _actionQueue[index] ; 

			        if ( pAction.IsDone() == true)
				        continue ; 
			        else 
			        {
				        pAction.Run();
				        allActionsDone = false ; 
				        break ; 
			        }
		        }

		        if (allActionsDone == true) 
		        {
			        _isProcessing = false ; 
			        _isDone = true ; 
		        }
	        }
	        else 
	        {
                if (_isProcessing == true ) 
                    _isProcessing = RunLogic();

                if (_isProcessing == false)
                    _isDone = true; 
                //_isProcessing = false ; 
                //_isDone = true ; 
	        }

	        return false ; 
        }

        /// <summary>
        /// 
        /// </summary>
        public void Reset() 
        {
	        if ( _actionQueue != null) 
	        {
		        for ( int index = 0 ; index < _actionQueue.Count() ; index ++ ) 
		        {
			        OutputAction pAction = _actionQueue[index] ; 
			        pAction.Reset() ; 
		        }
	        }

            this._isDone = false ;
            this._isProcessing = false; 
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool IsProcessing()  // action keeps getting Run method called on each cycle
        {
	        return _isProcessing ; 
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool IsDone() 		// action done - no other processing will be completed on action or sub actions
        {	
	        return _isDone ; 
        }	
    }
}
