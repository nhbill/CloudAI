﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariableStochasticLearningAutomaton.Agent
{
    public enum LogicOperator { And, Or};


    public class LogicalEventOperator
    {
        LogicalEventOperator _leOp = null;
        LogicalEventOperator _leOp2 = null;
        InputEvent _ieOp = null;
        InputEvent _ieOp2 = null;

        LogicOperator _operator ;
        InputEventManager _manager; 


        public LogicalEventOperator(InputEventManager manager, InputEvent evOp, LogicOperator op, InputEvent evOp2)
        {
            _leOp = null;
            _leOp2 = null;
            _ieOp = evOp;
            _ieOp2 = evOp2;
            _operator = op;
            _manager = manager; 
        }


        public LogicalEventOperator(InputEventManager manager, LogicalEventOperator evOp, LogicOperator op, InputEvent evOp2)
        {
            _leOp = evOp;
            _leOp2 = null;
            _ieOp = null;
            _ieOp2 = evOp2;
            _operator = op;
            _manager = manager;
        }

        public LogicalEventOperator(InputEventManager manager, LogicalEventOperator evOp, LogicOperator op, LogicalEventOperator evOp2)
        {
            _leOp = evOp;
            _leOp2 = evOp2;
            _ieOp = null;
            _ieOp2 = null;
            _operator = op;
            _manager = manager;
        }

        public bool RunLogic()
        {
            if (_ieOp != null && _ieOp2 != null)
            {
                if (_operator == LogicOperator.And)
                    return _manager.CheckEventIsPending(_ieOp) && _manager.CheckEventIsPending(_ieOp2);
                else if (_operator == LogicOperator.Or)
                    return _manager.CheckEventIsPending(_ieOp) || _manager.CheckEventIsPending(_ieOp2);
            }
            else if (_leOp != null && _ieOp2 != null)
            {
                if (_operator == LogicOperator.And)
                    return _leOp.RunLogic() && _manager.CheckEventIsPending(_ieOp2);
                else if (_operator == LogicOperator.Or)
                    return _leOp.RunLogic() || _manager.CheckEventIsPending(_ieOp2);
            }
            else if (_leOp != null && _leOp2 != null)
            {
                if (_operator == LogicOperator.And)
                    return _leOp.RunLogic() && _leOp2.RunLogic();
                else if (_operator == LogicOperator.Or)
                    return _leOp.RunLogic() || _leOp2.RunLogic();
            }
            // only one event set
            else if (_ieOp != null && _ieOp2 == null && _leOp == null && _leOp2 == null)
                return _manager.CheckEventIsPending(_ieOp);
            // only one event set
            else if (_ieOp == null && _ieOp2 != null && _leOp == null && _leOp2 == null)
                return _manager.CheckEventIsPending(_ieOp2);
            else
                throw new NotImplementedException();

            return false; 
        }

        public void Reset ()
        {
            if (_ieOp != null)
                _ieOp.ResetEvent();
            
            if(_ieOp2 != null)
                _ieOp.ResetEvent();

            if (_leOp != null)
                _leOp.Reset();

            if (_leOp2 != null)
                _leOp2.Reset();

        }
    }
}
