﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class TestOutputAction : OutputActionTimed
    {
        private string _name;
        private bool _value;

        public TestOutputAction(string name, int millis, string id) : base (millis, id)
        {
            _name = name; 
        }
        
        public string Name { get { return _name;  } set { _name = value;  }}


        public override bool DoTimedLogic()
        {
            _value = false;

            return _value; 
        }

        public override bool OnComplete()
        {
            _value = false;
            return true; 
        }

        public override string ToString()
        {
            if (_actionQueue != null && _actionQueue.Any())
            {
                string name = _name; 

                foreach ( OutputAction action in _actionQueue)
                {
                    TestOutputAction ta = ((TestOutputAction) action);
                    name += "|" + ta.Name;
                }
                return name; 
            }

            return _name;
        }

    }
}
