﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class AutonomousRobotEventManager : InputEventManager
    {
        public InputEvent FiddleList(InputEvent ev)
        {
            // add start frame for first event that comes through
            if (_eventsInterimHistory.Count() == 1 &&
                (_eventsInterimHistory[0].Event.GetType().Name.Contains("InputEvent") == true && timerValue == DateTime.MinValue ))
            {
                timerValue = DateTime.Now.AddMilliseconds(10000);
            }

            return ev;
        }


        DateTime timerValue = DateTime.MinValue; 

        public void PrePendingEventsFiddleList()
        {
            if (timerValue != DateTime.MinValue)
            {
                // less than 5000 ms elapsed...
                if (timerValue != DateTime.MinValue)
                {
                    if (timerValue >= DateTime.Now)
                    {
                        // any pending events?
                        if (_listPendingEvents.Any())
                        {
                            int numberAlready = _eventsInterimHistory.Count(e => e.Event.GetType().Name.Contains("ARLeftOrRightLimitSwitchAfterTryingStrategyEvent") == true);

                            // is this a repeat? if not change to generic message
                            if (numberAlready == 0)
                            {
                                if (_listPendingEvents[0].Store == "interimhistory" && _listPendingEvents[0].Operation == "add")
                                {
                                    // change event from a right or left limit switch hit to ARLeftOrRightLimitSwitchAfterTryingStrategyEvent object
                                    EventStamp stamp = new EventStamp(_events[3]);
                                    _listPendingEvents[0].Object = stamp;
                                    AddMotivation(new MotivationTimer(0, null, _events[3], false, 1, 0, false));
                                    timerValue = DateTime.MinValue;
                                    Result(false);
                                }
                            }
                        }
                    }
                    // more than 5 seconds elapsed
                    else if (timerValue <= DateTime.Now)
                    {
                        timerValue = DateTime.MinValue;
                        AddInputEventInterimHistory(_events[2]);
                        AddMotivation(new MotivationTimer(0, null, _events[2], true, 1, 0, false));
                        Result(true);
                    }
                }
            }
        }

    public override void InitializeManager()
        {
 
            _actionBase.Add(new ARBackupTurnLeftAction(2000));
            _actionBase.Add(new ARBackupTurnRightAction(2000));
            _actionBase.Add(new ARForwardTurnLeftAction(2000));
            _actionBase.Add(new ARForwardTurnRightAction(2000));

            _actionBase.Add(new ARGoBackwardAction(2000));
            _actionBase.Add(new ARGoForwardAction(2000));

            _actionBase.Add(new ARStopAction(2000));
            _actionBase.Add(new ARTurnLeftAction(2000));
            _actionBase.Add(new ARTurnRightAction(2000));

            InputEvent leftLimitSwitch = new ARLeftLimitSwitchInputEvent(_actionBase, false, true, true);
            InputEvent rightLimitSwitch = new ARRightLimitSwitchInputEvent(_actionBase, false, true, true);
            // InputEvent startEvent = new ARStartFrameEvent(_actionBase, false, true, false);
            InputEvent noEventEvent = new ARNoEventEvent(_actionBase, true, true, false);
            InputEvent limitSwitchEventAfterGivenStrategy = new ARLeftOrRightLimitSwitchAfterTryingStrategyEvent(_actionBase, true, true, false);


            //_events.Add(startEvent);
            _events.Add(leftLimitSwitch);
            _events.Add(rightLimitSwitch);
            _events.Add(noEventEvent);
            _events.Add(limitSwitchEventAfterGivenStrategy);
        }

        object _callback = null; 
        public void ResultCallback( object obj)
        {
            _callback = obj; 
        }

        public void Result (bool value)
        {
            Type type = _callback.GetType();

            MethodInfo mis = type.GetMethod("Result");
            object [] parameters = { value};
            mis.Invoke(_callback, parameters);
        }
    }


}
