﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class AutonomousRobotEvent : InputEvent
    {
        public AutonomousRobotEvent(IEnumerable<OutputAction> pActionList, bool isMotivator = false, bool isSetFrameBoundaryEvent = false, bool doesSystemRespondToEvent = false)
            : base(pActionList, isMotivator, isSetFrameBoundaryEvent, doesSystemRespondToEvent)
        {

        }

        public override bool RunLogic()
        {
            return true;
        }
        public override bool IsSimilar(InputEvent ev)
        {
            if (this == ev)
                return true;
            else
                return false;
        }
        public override bool IsMatch(InputEvent ev)
        {
            if (ev.GetType() == typeof(AutonomousRobotEvent))
            {
                // TODO:  include blocknumber later for this...
                if (((AutonomousRobotEvent)ev).Name == this.Name)
                    return true;
                else
                    return false;
            }

            return false;
        }


        public override void SendDebugInfo(string start, string end)
        {
            Console.WriteLine("Object:" + start + Name + " " + end);
        }

        public string Name { get; set; }

    }
}
