﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VariableStochasticLearningAutomaton.Agent.Interfaces; 

namespace VariableStochasticLearningAutomaton.Agent
{
    public class MotivationResult
    {
       
        public MotivationResult()
        {

        }

        public bool? Result { get; set; }

        public int Weight { get; set;  }

        public InputEvent Input { get; set; }
    }

    public class MotivationTimer : IMotivation
    {
        public static List<InputEvent> MotivationEvents = new List<InputEvent>();

        private static MotivationResult _motivationResult = new MotivationResult();

        bool _started = false;
        int _inputEventFinalCountInStartingQueue = 0;
        InputEvent _inputEventStart = null;
        InputEvent _inputEventFinal = null;
        bool _valueToReturnOnEventFinalOccurring;
        int _desiredWeightForSuccess;

        private DateTime _dtTimeToWaitAtEnd = DateTime.MinValue;
        private int _msAfterEnd = 0;
        Boolean _boolMotivationEventCanStartFrame = false;

        int _msTimeSpan;
        DateTime _endTime;
        InputEventManager _manager = null; 

        /// <summary>
        /// 
        /// </summary>
        /// <param name="milliseconds"></param>
        public MotivationTimer(int milliseconds)
        {
            _msTimeSpan = milliseconds;
        }

        public MotivationResult GetMotivationResult()
        {
            return new MotivationResult() { Input = _inputEventFinal, Result = _valueToReturnOnEventFinalOccurring, Weight = _desiredWeightForSuccess };
        }

        /// <summary>
        /// 1  milliseconds is int, evStart == null, evFinal != null valueToReturnOnEvFinalOccurring
        ///     after Start() method is called, will wait milliseconds - meanwhile any calls to CheckIfMotivationEventOccurs()
        ///     will return null - if evFinal occurs during time, will return valueToReturnOnEvFinalOccurring 
        ///     - at end of wait time, will return valueToReturnOnEvFinalOccurring 
        ///     
        /// 2. milliseconds is int, evStart != null, evFinal != null valueToReturnOnEvFinalOccurring
        ///     if evStart occurs, will call Start()
        ///     after Start() method is called, will wait milliseconds - meanwhile any calls to CheckIfMotivationEventOccurs()
        ///     will return null - if evFinal occurs during time, will return valueToReturnOnEvFinalOccurring 
        ///     - at end of wait time, will return valueToReturnOnEvFinalOccurring 
        /// -
        /// </summary>
        /// <param name="milliseconds"></param>
        /// <param name="evStart"></param>
        /// <param name="evFinal"></param>
        public MotivationTimer(InputEventManager manager, int milliseconds, InputEvent evStart, InputEvent evFinal, bool valueToReturnOnEvFinalOccurring, int resultWeight = 1, int msToWaitSAtEnd = 0, bool boolMotivationEventCanStartFrame = false)
        {
            _manager = manager; 
            _inputEventStart = evStart;
            _inputEventFinal = evFinal;
            _msTimeSpan = milliseconds;
            TriggeredResult = _valueToReturnOnEventFinalOccurring = valueToReturnOnEvFinalOccurring;

            _desiredWeightForSuccess = resultWeight;

            MotivationTimer.MotivationEvents.Add(evFinal);

            _msAfterEnd = msToWaitSAtEnd;
            _boolMotivationEventCanStartFrame = boolMotivationEventCanStartFrame;
        }

        public bool TriggeredResult { get; set;  }

        public Boolean MotivationEventCanStartFrame
        {
            get { return _boolMotivationEventCanStartFrame; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public MotivationResult CheckIfMotivationEventOccurs()
        {
            MotivationResult returnValue = null;

            // look to start only if start input event has occurred - does summary 2 in notes section
            if (_started == false && _inputEventStart != null)
            {
                if (CheckIfEventOccurred(_inputEventStart))
                    Start();
            }

            // look to only if no start input event and has a final event - does scenario summary in notes section
            if (_started == false && _inputEventFinal != null && _inputEventStart == null)
            {
                Start(); 
            }

            bool endingEventOccurred = _inputEventFinal.IsOccurring();

            if (_dtTimeToWaitAtEnd == DateTime.MinValue && endingEventOccurred == true && _started == true && _msAfterEnd > 0)
            {
                _dtTimeToWaitAtEnd = _dtTimeToWaitAtEnd.Add(new TimeSpan(0, 0, 0, 0, _msAfterEnd));
            }

            // started looking at motivations and the ending event occurred 
            if (_started == true && endingEventOccurred == true && _inputEventFinal != null && 
                (_dtTimeToWaitAtEnd == DateTime.MinValue || (_dtTimeToWaitAtEnd != DateTime.MinValue && _dtTimeToWaitAtEnd > DateTime.Now) ))
            {
                _motivationResult.Result = _valueToReturnOnEventFinalOccurring;
                _motivationResult.Weight = _desiredWeightForSuccess;
                returnValue = _motivationResult; 

                Reset(); 
            }

            // ran out of time and ending event never occurred
            if (_started == true && endingEventOccurred == false && _endTime < DateTime.Now && _inputEventFinal != null)
            {
                _motivationResult.Result = !_valueToReturnOnEventFinalOccurring;
                _motivationResult.Weight = 1;
                returnValue = _motivationResult;

                // returnValue = !_valueToReturnOnEventFinalOccurring;
                Reset(); 
            }

            return returnValue;
        }

        protected bool CheckIfEventOccurred(InputEvent ev)
        {
            if (ev != null)
                return _manager.GetEventsInterimHistoryList().Select(s => s.Event).Contains(ev);
            else
                return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected int GetInputEventFinalCountInEventQueue()
        {
            int count = 0;
            foreach (InputEvent ev in _manager.GetEventsInterimHistoryList().Select(s => s.Event))
            {
                if (ev == _inputEventFinal)
                    count++;
            }
            return count;
        }

        /// <summary>
        ///  called on first call to CheckIfMotivationEventOccurs() if not started already
        /// </summary>
        public void Start()
        {
            _started = true;
            _inputEventFinalCountInStartingQueue = GetInputEventFinalCountInEventQueue();   
            _endTime = DateTime.Now.AddMilliseconds((double)_msTimeSpan); 

             
        }

        /// <summary>
        /// 
        /// </summary>
        public void Reset()
        {
            _started = false;
            _endTime = DateTime.MinValue;
            _inputEventFinalCountInStartingQueue = 0;

            if (_inputEventStart != null)
                _inputEventStart.ResetEvent();

            if (_inputEventFinal != null)
                _inputEventFinal.ResetEvent();
        }
    }
}
