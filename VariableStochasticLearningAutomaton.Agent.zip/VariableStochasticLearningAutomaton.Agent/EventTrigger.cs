﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariableStochasticLearningAutomaton.Agent
{
    public enum EventTriggerAction { Nothing, ReplaceEvent, AddToQueue };
    public class EventTrigger
    {
        public EventTriggerAction Action { get; set; }

        InputEvent _event;
        public InputEvent Event {  get { return _event; } }

        public EventTrigger(EventTriggerAction action, InputEvent ev)
        {
            Steps = new List<Step>();
            Action = action;
            _event = ev;
            CurrentStep = null;
            Completed = false;
        }

        public bool RemoveTriggerEvent
        {
            get
            {
                return Completed && (Action == EventTriggerAction.ReplaceEvent);
            }
        }

        public bool Completed { get; set; }

        public Step CurrentStep { get; set;  }
        public List<Step> Steps { get; set;  }

        public bool RunLogic()
        {
            if (CurrentStep == null && Steps.Count >= 1)
            {
                CurrentStep = Steps[0];
                CurrentStep.Start();
            }

            bool foundCurrentInList = false;
            for (int index = 0; index < Steps.Count; index++)
            {
                if (foundCurrentInList == false && CurrentStep == Steps[index])
                {
                    foundCurrentInList = true;
                }
                else
                    continue;

                if (foundCurrentInList == true)
                {
                    if (CurrentStep.IfCompleted() == true)
                    {
                        // if last one, then we are complete...
                        if (index == (Steps.Count - 1))
                        {
                            Completed = true;
                        }
                        else
                        {
                            CurrentStep = Steps[index + 1];
                            CurrentStep.Start();
                        }
                    }
                }
            }

            return Completed; 
        }

        public void Reset ()
        {
            Completed = false;
            CurrentStep = null; 

            foreach(Step step in this.Steps)
            {
                step.Reset(); 
            }
        }

    }
}
