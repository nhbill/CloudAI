﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class InputEventParent : InputEvent 
    {
        public InputEventParent(IEnumerable<OutputAction> pActionList) :
            base(pActionList, "")
        {
            
        }

        public bool IsMatch(InputEvent ev)
        {
            bool results = false; 

            if (ev.GetEvents() != null && this.GetEvents() != null && ev.GetEventCount() == this.GetEventCount())
            {
                results = true; 
                IEnumerable <InputEvent> list = ev.GetEvents();
                for (int index = 0 ; index < ev.GetEventCount(); index ++)
                {
                    if (this.GetEvents().ElementAt(index).IsMatch(list.ElementAt(index)) == false)
                    {
                        results = false;
                        break; 
                    }
                }
            }

            return results; 

        }

        public void SendDebugInfo(string start, string end)
        {
            Console.WriteLine("Complex event:  ");
            if (this.GetEvents() != null)
            {
                foreach(InputEvent ev in this.GetEvents())
                {
                    ev.SendDebugInfo("","");
                }
            }
        }

        public bool IsSimilar(InputEvent ev)
        {
            if (this == ev)
                return true; 
            else
                return false; 
        }

        public bool RunLogic()
        {
            return false;
        }

        private string _name = ""; 
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string ToString()
        {
            if (_eventsList != null && _eventsList.Any())
            {
                string name = _name;

                foreach (InputEvent action in _eventsList)
                {
                    name += "|" + action.Name;
                }
                return name;
            }

            return _name;
        }

        object _callback = null;
        public void ResultCallback(object obj)
        {
            _callback = obj;
        }

        public void Result(bool value)
        {
            Type type = _callback.GetType();

            MethodInfo mis = type.GetMethod("Result");
            object[] parameters = { value };
            mis.Invoke(_callback, parameters);
        }


    }
}
