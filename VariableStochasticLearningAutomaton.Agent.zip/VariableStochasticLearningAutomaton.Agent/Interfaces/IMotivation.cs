﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VariableStochasticLearningAutomaton.Agent.Interfaces
{
    public interface IMotivation
    {
        // returns null while waiting, true or false if it occurs or not
        MotivationResult CheckIfMotivationEventOccurs();
        void Start();
        void Reset();
        MotivationResult GetMotivationResult();

        bool TriggeredResult { get; set;  }
    }
}
