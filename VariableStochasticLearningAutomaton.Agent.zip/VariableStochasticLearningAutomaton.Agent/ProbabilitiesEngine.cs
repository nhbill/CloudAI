﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class ProbabilitiesEngine
    {
	    private List<OutputAction> _actionList ;

        private List<double> _denominators = new List<double>();
        private List<double> _numerators = new List<double>(); 
	    private List<double> _probabilities = new List<double>();
        private List<short> _successCount = new List<short>();


        private InputEvent _parent = null; 

	    private float _learnDenominator ; 
	    private float _learnNumerator ; 
	    private float _learnParameter ; 
        
        private static float LEARNING_DENOMINATOR  = 1.0F;
        private static float LEARNING_NUMERATOR  = 2.0F;

        public void ResetActions()
        {
            foreach(OutputAction action in _actionList)
            {
                action.Reset(); 
            }
        }

        private void Initialize() 
        {
            for (int index = 0; index < _denominators.Count(); index++) 
	        {
		        _denominators [index] = 0 ; 
		        _numerators[index] = 0 ; 
		        _probabilities[index] = 0 ; 
	        }

	        CalculateLearningParameter(LEARNING_DENOMINATOR, LEARNING_NUMERATOR);
        }

        public float CalculateLearningParameter ( float numerator, float denominator ) 
        {
	        _learnParameter = numerator / denominator ; 
	        _learnNumerator = numerator ; 
	        _learnDenominator = denominator ; 

	        return _learnParameter;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="activities"></param>
        public ProbabilitiesEngine(IEnumerable<OutputAction> activities, InputEvent parent)
        {
	        Initialize() ; 
	        BuildProbabilitiesMap(  activities ) ;
            _parent = parent;
        }
         
        /// <summary>
        /// creates a deep copy of existing ProbabilityEngine
        /// </summary>
        /// <returns></returns>
        public ProbabilitiesEngine Clone()
        {
            ProbabilitiesEngine engine = new ProbabilitiesEngine(this._actionList, _parent);
            for ( int index = 0 ; index < _actionList.Count() ; index ++ )
            {
                engine._denominators[index] = _denominators[index];
                engine._numerators[index] = _numerators[index] ;
                engine._probabilities[index] = _probabilities[index] ;
                engine._successCount[index] = _successCount[index] ; 
            }
            
            return engine; 
        }

        /// <summary>
        /// finds any negative feedbacks and reinforces as if the event occurred reinforcementValuea
        /// number of times
        /// <param name="threshold"></param>
        /// <param name="reinforcementValue"></param>
        public void ReinforceNegativeFeedback(short threshold, int reinforcementValue = 1)
        {
            for (int index = _actionList.Count() - 1; index >= 0; index--)
            {
                if (_successCount[index] <= threshold)
                {
                    for ( int inner = 0 ; inner < reinforcementValue; inner ++ ) 
                        ChangeProbabilitiesFromInput(_actionList[index], false);
                }
            }

        }

        /// <summary>
        /// finds any positive feedbacks and reinforces as if the event occurred reinforcementValuea
        /// number of times
        /// </summary>
        /// <param name="threshold"></param>
        public void ReinforcePositiveFeedback(short threshold, int reinforcementValue = 1)
        {
            for (int index = _actionList.Count() - 1; index >= 0; index--)
            {
                if (_successCount[index] >= threshold)
                    for ( int inner = 0 ; inner < reinforcementValue; inner ++ ) 
                        ChangeProbabilitiesFromInput(_actionList[index], true); 
            }
        }
        
        /// <summary>
        /// remove feedback that is unsuccessful at least absolute value of threshold times
        /// </summary>
        /// <param name="threshold"></param>
        public void RemoveNegativeFeedback(short threshold)
        {
            for (int index = _actionList.Count() - 1; index >= 0; index--)
            {
                if (_successCount[index] <= threshold)
                {
                    _successCount.RemoveAt(index);
                    _actionList.RemoveAt(index);
                    _probabilities.RemoveAt(index);
                    _denominators.RemoveAt(index);
                    _numerators.RemoveAt(index); 
                }
            }
        }

        /// <summary>
        /// method adds a number of actions to probability and then recalculates based on success or failure 
        /// from previous experience
        /// </summary>
        /// <param name="actions"></param>
        public void AddToAndRecalcProbabilityMap(IEnumerable<OutputAction> actions)
        {
            _actionList.AddRange(actions);

            for (int index = 0; index < actions.Count(); index++)
            {
                _denominators.Add((float)0.0);
                _numerators.Add((float)0.0);
                _successCount.Add(0);
                _probabilities.Add((float)0.0); 
            }        

            for (int index = 0; index < _actionList.Count(); index++)
            {
                _denominators[index] = (float)_actionList.Count();
                _numerators[index] = (float)1.0;
            }

            EqualizeProbabilityMap();
            RecalculateProbabilitiesMap() ;
            CalculateProbabilities();
        }

        public void EqualizeProbabilityMap () 
        {
            for (int index = 0; index < _actionList.Count(); index++)
            {
                _denominators[index] = (float)_actionList.Count();
                _numerators[index] = (float)1.0;
            }  
        }
        
        public void RecalculateProbabilitiesMap() 
        {

            // change probabilities to accomodate the 
            for (int index = 0; index < _successCount.Count(); index++)
            {
                if (_successCount[index] > 0)
                {
                    for (int inner = 0; inner < _successCount[index]; inner++)
                    {
                        ChangeProbabilitiesFromInput(_actionList[index], true);
                    }
                }
                else if (_successCount[index] < 0)
                {
                    for (int inner = _successCount[index]; inner < 0; inner++)
                    {
                        ChangeProbabilitiesFromInput(_actionList[index], false);
                    }
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="actionList"></param>
        public void BuildProbabilitiesMap(IEnumerable<OutputAction> actionList) 
        {
	        _actionList = new List<OutputAction>(actionList);

	        for ( int index = 0 ; index < actionList.Count() ; index ++ ) 
	        {
  
                _denominators.Add((float)_actionList.Count());
                _numerators.Add(1.0F);
                _successCount.Add(0); 
	        }

	        CalculateProbabilities() ;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public OutputAction GetProbableAction() 
        {
        int returnValue = -1 ;
        bool tryAgain = true;
        int attempts = 0; 
            
            while (tryAgain == true)
            {
                attempts++;
                Random random = new Random((int)DateTime.Now.Ticks);
                int result = random.Next(10000);

                double probNumber = ((double)result / (double)10000.0);
                double startPoint = 0.0F;
                double endPoint = 0.0F;
                int count = _actionList.Count();

                // if the first value that comes back is 0, our algorithm is unhappy 
                if (result != 0)
                {
                    for (int index = 0; index < count; index++)
                    {

                        if (index == 0)
                            endPoint = _probabilities[index];

                        if (probNumber > startPoint && probNumber <= endPoint)
                        {
                            returnValue = index;
                            break;
                        }

                        if (index != (count - 1))
                        {
                            startPoint += _probabilities[index];
                            endPoint += _probabilities[index + 1];
                        }
                    }
                }
                else
                    returnValue = 0;

                int changes = _listChangeInputs.Count(s => s.Changes <= -1 && s.Action == _actionList[returnValue]);

                if (attempts <= 20 && changes >= 1)
                    tryAgain = true;
                else
                    tryAgain = false;
            }

            Console.WriteLine("OutputAction selected:  " + returnValue);

            if (returnValue != -1)
                return _actionList[returnValue];
            else
                return null;
        }

        /// <summary>
        /// 
        /// </summary>
        public void CalculateProbabilities() 
        {
            if (_probabilities.Count() != 0)
            {
                for (int index = 0; index < _actionList.Count(); index++)
                {
                    _probabilities[index] = (_numerators[index] / _denominators[index]);
                }
            }
            else
            {
                for (int index = 0; index < _actionList.Count(); index++)
                {
                    _probabilities.Add(_numerators[index] / _denominators[index]);
                }
            }
        }

        protected class ChangeInput
        {
            public OutputAction Action { get; set; }
            public int Changes { get; set; }

            public InputEvent Event { get; set; }
        }


        List<ChangeInput> _listChangeInputs = new List<ChangeInput>();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pAction"></param>
        /// <param name="favorable"></param>
        public void ChangeProbabilitiesFromInput ( OutputAction pAction, bool favorable )
        {
            ChangeInput change = _listChangeInputs.FirstOrDefault(s => s.Action == pAction);

            if (change == null)
            {
                change = new ChangeInput() { Changes = 0, Action = pAction, Event = _parent };
                _listChangeInputs.Add(change);
            }

            if (favorable == true)
                change.Changes++;
            else
                change.Changes--;
            
            if ( pAction != null ) 
	        {
		        int k = -1 ;

		        // which action number was it from the list 
		        for ( int index = 0 ; index < _actionList.Count() ; index ++)
		        {
			        if (pAction == _actionList[index])
			        {
				        k = index + 1;
                        
                        if (favorable == true)
                            _successCount[index]++;
                        else
                            _successCount[index]--;
                         
				        break ; 
			        }
		        }

		        for ( int index = 0 ; index < _actionList.Count() && k >= 0; index ++)
		        {

			        if (k == (index+1) && favorable == true) 
			        {
				        _numerators[index]= (_learnDenominator * _numerators[index]) + (_learnNumerator * (_denominators[index] - _numerators[index]));
				        // t_1=((v*t_1)+(u*(y_1-t_1))); //according updating rule when action alpha_1 was chosen and beta=0 (j=i)
				        _denominators[index]= _learnDenominator * _denominators [index];
				        // y_1=(v*y_1);
			        }

			        if (k == (index+1) && favorable == false ) 
			        {
				        _numerators[index]= _numerators[index] * (_learnDenominator - _learnNumerator) ;
				        //t_1=(t_1*(v-u)); //according updating rule when action alpha_1 was chosen and beta=1 (j=i)
				        _denominators[index]= _learnDenominator * _denominators[index];
				        //y_1=(v*y_1);
			        }
			        if (k != (index+1) && favorable == true ) 
			        {
				        _numerators[index]= _numerators[index]* (_learnDenominator - _learnNumerator) ;
				        //t_1=(t_1*(v-u)); //according updating rule when action alpha_1 was not chosen and beta=0 (j≠i)
				        _denominators[index]= _learnDenominator * _denominators[index];
				        // y_1=(v*y_1);
			        }

			        if (k != (index+1) && favorable == false) 
			        {
				        _numerators[index]= (_denominators[index] * _learnNumerator) + (_numerators[index] * (_actionList.Count() -1) * (_learnDenominator - _learnNumerator)) ;
				        // t_1=((y_1*u)+(t_1*(r-1)*(v-u))); //according updating rule when action alpha_1 was not chosen and beta=1 (j≠i)
				        _denominators[index]= (_denominators[index] * _learnDenominator * (_actionList.Count() -1));
				        //y_1=(y_1*v*(r-1));
			        }

                    float euclid = gcd((long)_numerators[index], (long)_denominators[index]); //find greatest common divisor (gcd) and devide denominators and numerators by gcd to reduce fraction
               
                    _numerators[index] = _numerators[index] / euclid;
                    _denominators[index] = _denominators[index] / euclid; 

		        }
	        }
        }

        //======================================== Euclidean algorithm ========================================
        private long gcd(long a, long b) 
        {
          if (b == 0) {
            return a;
          } if (b == 1) {
            return 1;
          } return gcd(b, a % b);
        }

        private void CalculateEuclid( int index ) 
        {
	        long euclid= gcd((long)_denominators[index], (long)_numerators[ index]);

	        _denominators[index]= _denominators[index]/ euclid;
	        _numerators[index]= _numerators[index]/ euclid;
        }
    }
}
