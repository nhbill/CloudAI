﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class ProbabilitiesEnginev2
    {
        private List<OutputAction> _actionList;

        private List<long> _denominators = new List<long>();
        private List<long> _numerators = new List<long>();
        private List<double> _probabilities = new List<double>();

        private InputEvent _parent = null;

        private float _learnDenominator;
        private float _learnNumerator;
        private float _learnParameter;

        private static float LEARNING_DENOMINATOR = 1.0F;
        private static float LEARNING_NUMERATOR = 2.0F;

        public void ResetActions()
        {
            foreach (OutputAction action in _actionList)
            {
                action.Reset();
            }
        }

        private void Initialize()
        {
            int denominator = (_actionList.Count() * _actionList.Count()) * 2; 

            for (int index = 0; index < _actionList.Count(); index++)
            {
                _denominators.Add(denominator);
                _numerators.Add(_actionList.Count() * 2);
            }

            CalculateProbabilities(); 
        }

        public double GetActionPercent(string id)
        {
            double percentage = -100.0F;
            for (int index = 0; index < _actionList.Count(); index++)
            {
                if (id == _actionList[index].Id)
                {
                    percentage = _probabilities[index] * 100.0;
                    break; 
                }
            }

            return percentage;
        }

        public double GetActionPercent (OutputAction action)
        {
            return GetActionPercent(action.Id);
        }

        public float CalculateLearningParameter(float numerator, float denominator)
        {
            _learnParameter = numerator / denominator;
            _learnNumerator = numerator;
            _learnDenominator = denominator;

            return _learnParameter;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="activities"></param>
        public ProbabilitiesEnginev2(IEnumerable<OutputAction> activities, InputEvent parent)
        {
            _actionList = new List<OutputAction>(activities);
            //BuildProbabilitiesMap(activities);

            Initialize();
            
            _parent = parent;
        }

        /// <summary>
        /// creates a deep copy of existing ProbabilityEngine
        /// </summary>
        /// <returns></returns>
        public ProbabilitiesEnginev2 Clone()
        {
            //ProbabilitiesEngine engine = new ProbabilitiesEngine(this._actionList, _parent);
            //for (int index = 0; index < _actionList.Count(); index++)
            //{
            //    engine._denominators[index] = _denominators[index];
            //    engine._numerators[index] = _numerators[index];
            //    engine._probabilities[index] = _probabilities[index];
            //    engine._successCount[index] = _successCount[index];
            //}

            //return engine;
            return null; 
        }

        /// <summary>
        /// finds any negative feedbacks and reinforces as if the event occurred reinforcementValuea
        /// number of times
        /// <param name="threshold"></param>
        /// <param name="reinforcementValue"></param>
        public void ReinforceNegativeFeedback(short threshold, int reinforcementValue = 1)
        {
            //for (int index = _actionList.Count() - 1; index >= 0; index--)
            //{
            //    if (_successCount[index] <= threshold)
            //    {
            //        for (int inner = 0; inner < reinforcementValue; inner++)
            //            ChangeProbabilitiesFromInput(_actionList[index], false);
            //    }
            //}

        }

        /// <summary>
        /// finds any positive feedbacks and reinforces as if the event occurred reinforcementValuea
        /// number of times
        /// </summary>
        /// <param name="threshold"></param>
        public void ReinforcePositiveFeedback(short threshold, int reinforcementValue = 1)
        {
            //for (int index = _actionList.Count() - 1; index >= 0; index--)
            //{
            //    if (_successCount[index] >= threshold)
            //        for (int inner = 0; inner < reinforcementValue; inner++)
            //            ChangeProbabilitiesFromInput(_actionList[index], true);
            //}
        }

        /// <summary>
        /// remove feedback that is unsuccessful at least absolute value of threshold times
        /// </summary>
        /// <param name="threshold"></param>
        public void RemoveNegativeFeedback(short threshold)
        {
            //for (int index = _actionList.Count() - 1; index >= 0; index--)
            //{
            //    if (_successCount[index] <= threshold)
            //    {
            //        _successCount.RemoveAt(index);
            //        _actionList.RemoveAt(index);
            //        _probabilities.RemoveAt(index);
            //        _denominators.RemoveAt(index);
            //        _numerators.RemoveAt(index);
            //    }
            //}
        }

        /// <summary>
        /// method adds a number of actions to probability and then recalculates based on success or failure 
        /// from previous experience
        /// </summary>
        /// <param name="actions"></param>
        public void AddToAndRecalcProbabilityMap(IEnumerable<OutputAction> actions)
        {
            //_actionList.AddRange(actions);

            //for (int index = 0; index < actions.Count(); index++)
            //{
            //    _denominators.Add(0);
            //    _numerators.Add(0);
            //    //_successCount.Add(0);
            //    _probabilities.Add(0);
            //}

            //for (int index = 0; index < _actionList.Count(); index++)
            //{
            //    _denominators[index] = _actionList.Count();
            //    _numerators[index] = 1;
            //}

            //EqualizeProbabilityMap();
            //RecalculateProbabilitiesMap();
            //CalculateProbabilities();
        }

        public void EqualizeProbabilityMap()
        {
            for (int index = 0; index < _actionList.Count(); index++)
            {
                _denominators[index] = _actionList.Count();
                _numerators[index] = 1;
            }
        }

        public void RecalculateProbabilitiesMap()
        {

            // change probabilities to accomodate the 
            //for (int index = 0; index < _successCount.Count(); index++)
            //{
            //    if (_successCount[index] > 0)
            //    {
            //        for (int inner = 0; inner < _successCount[index]; inner++)
            //        {
            //            ChangeProbabilitiesFromInput(_actionList[index], true);
            //        }
            //    }
            //    else if (_successCount[index] < 0)
            //    {
            //        for (int inner = _successCount[index]; inner < 0; inner++)
            //        {
            //            ChangeProbabilitiesFromInput(_actionList[index], false);
            //        }
            //    }
            //}
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="actionList"></param>
        public void BuildProbabilitiesMap(IEnumerable<OutputAction> actionList)
        {
            _actionList = new List<OutputAction>(actionList);

            for (int index = 0; index < actionList.Count(); index++)
            {
                _denominators.Add(_actionList.Count());
                _numerators.Add(1);
            }

            CalculateProbabilities();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public OutputAction GetProbableAction()
        {
            int returnValue = -1;
            bool tryAgain = true;
            int attempts = 0;

            while (tryAgain == true)
            {
                attempts++;
                Random random = new Random((int)DateTime.Now.Ticks);
                int result = random.Next(10000);

                double probNumber = ((double)result / (double)10000.0);
                double startPoint = 0.0F;
                double endPoint = 0.0F;
                int count = _actionList.Count();

                // if the first value that comes back is 0, our algorithm is unhappy 
                if (result != 0)
                {
                    for (int index = 0; index < count; index++)
                    {

                        if (index == 0)
                            endPoint = _probabilities[index];

                        if (probNumber > startPoint && probNumber <= endPoint)
                        {
                            returnValue = index;
                            break;
                        }

                        if (index != (count - 1))
                        {
                            startPoint += _probabilities[index];
                            endPoint += _probabilities[index + 1];
                        }
                    }
                }
                else
                    returnValue = 0;

                int changes = _listChangeInputs.Count(s => s.Changes <= -1 && s.Action == _actionList[returnValue]);

                if (attempts <= 20 && changes >= 1)
                    tryAgain = true;
                else
                    tryAgain = false;
            }

            Console.WriteLine("OutputAction selected:  " + returnValue);

            if (returnValue != -1)
                return _actionList[returnValue];
            else
                return null;
        }

        /// <summary>
        /// 
        /// </summary>
        public void CalculateProbabilities()
        {
            if (_probabilities.Count() != 0)
            {
                for (int index = 0; index < _actionList.Count(); index++)
                {
                    _probabilities[index] = ((double)_numerators[index] / (double)_denominators[index]);
                }
            }
            else
            {
                if (_actionList != null)
                {
                    for (int index = 0; index < _actionList.Count(); index++)
                    {
                        _probabilities.Add((double)_numerators[index] / (double)_denominators[index]);
                    }
                }
            }
        }

        protected class ChangeInput
        {
            public OutputAction Action { get; set; }
            public int Changes { get; set; }

            public InputEvent Event { get; set; }

            public long Index { get; set; }
        }


        private int GetActionNumber(OutputAction action)
        {
            int index = -1; 
            for(int counter = 0; counter < _actionList.Count(); counter++)
            {
                OutputAction act = _actionList[counter]; 

                if ( act == action)
                {
                    index = counter; 
                    break; 
                }
            }

            return index; 
        }

        List<ChangeInput> _listChangeInputs = new List<ChangeInput>();
        int _minimumNegativeFeedbackOnOutput = 2; 

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pAction"></param>
        /// <param name="favorable"></param>
        public void ChangeProbabilitiesFromInput(OutputAction pAction, bool favorable)
        {
            if (pAction == null)
            {
                // throw new Exception("ProbabilitiesEnginev2::ChangeProbabilitiesFromInput - OutputAction cannot be null");
                Console.WriteLine("\n OutputAction  is null -cannot do ChangeProbabilitiesFromInput \n");
                return;
            }

            TestNumerators();

            ChangeInput change = _listChangeInputs.FirstOrDefault(s => s.Action == pAction);

            if (change == null)
            {
                change = new ChangeInput() { Changes = 0, Action = pAction, Event = _parent, Index = GetActionNumber(pAction) };
                _listChangeInputs.Add(change);
                _listChangeInputs = _listChangeInputs.OrderByDescending(s => s.Index).ToList();
            }

            if (favorable == true)
                change.Changes++;
            else
                change.Changes--;

            // what will the offsets be?
            int offsetAction = GetDenominatorOffsetValue(favorable);
            int offsetEverythingElse = GetDenominatorDefaultOffset(favorable);
            
            for (int index = 0; index != _numerators.Count(); index ++)
            {
                if (change.Index == index)
                {
                    _numerators[(int)change.Index] += offsetAction;
                    continue;
                }
                _numerators[index] += offsetEverythingElse;
            }

            // find all values that are < 0 and add their values up
            long leftOverOffsets = 0;
            for( int index = 0; index < _numerators.Count(); index++)
            {
                if ( _numerators[index] < 0)
                {
                    ChangeInput input = _listChangeInputs.FirstOrDefault(s => s.Index == index);

                    leftOverOffsets += (_numerators[index] * -1);
                    _numerators[index] = 0; 

                    if ( input != null)
                    {
                        // hasn't enough negative yet to be zero, so leave it at 1 so will be used in random Output lookup
                        if ( input.Changes > _minimumNegativeFeedbackOnOutput)
                        {
                            leftOverOffsets += -1;
                            _numerators[index] = 1;
                        }
                    }
                }
            }

            if (leftOverOffsets != 0)
            {
                // redistribute what is given back amongst available denominators...
                int available = _numerators.Count(s => s != 0);
                float offsetPerAvailable = (float)leftOverOffsets / (float)available;
                long leftOver = leftOverOffsets % available;
                List<int> listAvailableIndexes = new List<int>();
                bool positive = leftOverOffsets < 0 || offsetPerAvailable < 0;

                // get list of available indexes where can do an offset...
                for (int index = 0; index < _numerators.Count(); index++)
                {
                    if (_numerators[index] != 0 && index != change.Index)
                        listAvailableIndexes.Add(index);
                }

                // do the offset if there is an offset for each in the list...
                for (int index = 0; ((int)offsetPerAvailable != 0) && index < listAvailableIndexes.Count(); index++)
                {
                    if (positive)
                        _numerators[listAvailableIndexes[index]] += (int)offsetPerAvailable;
                    else
                        _numerators[listAvailableIndexes[index]] += ((int)offsetPerAvailable*-1);
                }

                // if had any leftover items, randomly assign them from within the available list of items.
                if (leftOver != 0)
                {
                    
                    if (positive == true)
                        leftOver = leftOver * -1; 
                    Random random = new Random((int)DateTime.Now.Ticks);
                    for (int index = 0; index < leftOver; index++)
                    {
                        bool valueApplied = false;
                        do
                        {
                            int value = random.Next() % listAvailableIndexes.Count();

                            if (_numerators[listAvailableIndexes[value]] == 0)
                                continue;
                            else
                                valueApplied = true;

                            if (positive)
                                _numerators[listAvailableIndexes[value]] += 1;
                            else
                                _numerators[listAvailableIndexes[value]] += -1;
                        }
                        while (valueApplied == false);
                    }
                }
                TestNumerators(); 
            }
        }

        List<int> GetListOfNonZeroIndices()
        {
            List<int> listAvailableIndexes = new List<int>() ; 
            for (int index = 0; index < _numerators.Count(); index++)
            {
                if (_numerators[index] != 0 && index > 1)
                    listAvailableIndexes.Add(index);
            }

            return listAvailableIndexes; 
        }

        private void TestNumerators ()
        {
            long testValue = 0;
            for (int index = 0; index < _numerators.Count(); index++)
            {
                testValue += _numerators[index];
            }

            int value = (_actionList.Count() * _actionList.Count()) * 2; 

            if (testValue != value)
            {
                long offset = testValue - value ;
                bool positive = false;

                if (offset > 0)
                    positive = true;
                else
                    offset = offset * -1; 

                //throw new Exception("denominators are out of wack...");
                List<int> listAvailableNonZeroIndexes = GetListOfNonZeroIndices();

                for ( int index = 0, counter = 0; index < listAvailableNonZeroIndexes.Count() && counter < offset; index ++)
                {
                    if ( _denominators[(int)listAvailableNonZeroIndexes[index]] > 0 && positive == true)
                    {
                        _denominators[(int)listAvailableNonZeroIndexes[index]] -= 1;
                        counter++;
                    }
                    else 
                    {
                        _denominators[(int)listAvailableNonZeroIndexes[index]] += 1;
                        counter++;
                    }

                    if (index == (listAvailableNonZeroIndexes.Count() -1) && counter < offset)
                    {
                        index = 0; 
                    }
                }
            }
        }

        private int GetDenominatorDefaultOffset(bool success)
        {
            if (success == true)
                return -1;

            return 1; 
        }

        private int GetDenominatorOffsetValue(bool success)
        {
            int offset = _denominators.Count() - 1;
            if ( success == false)
            {
                offset = offset * -1; 
            }

            return offset; 
        }

        //======================================== Euclidean algorithm ========================================
        private long gcd(long a, long b)
        {
            if (b == 0)
            {
                return a;
            }
            if (b == 1)
            {
                return 1;
            }
            return gcd(b, a % b);
        }

        private void CalculateEuclid(int index)
        {
            long euclid = gcd((long)_denominators[index], (long)_numerators[index]);

            _denominators[index] = _denominators[index] / euclid;
            _numerators[index] = _numerators[index] / euclid;
        }
    }
}
