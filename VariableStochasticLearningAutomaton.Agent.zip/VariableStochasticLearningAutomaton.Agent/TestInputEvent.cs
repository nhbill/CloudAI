﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class TestInputEvent : InputEvent
    {
        private string _name;
        private bool _value = false; 
        public TestInputEvent(string name, IEnumerable<OutputAction> pActionList) 
            : base (pActionList, "")
        {
            _name = name; 
        }

        public bool IsMatch(InputEvent ev)
        {
            throw new NotImplementedException();
        }

        public bool IsSimilar(InputEvent ev)
        {
            if (this == ev)
                return true;
            else
                return false;
        }

        public void SendDebugInfo(string start, string end)
        {

        }

        public bool RunLogic()
        {
            return _value; 
        }

        public void SetValue( bool? value = null)
        {
            if (value == null)
            {
                if (_value == false)
                    _value = true;
                else
                    _value = false;
            }
            else
                _value = (bool)value; 
        }
        
        public override string ToString()
        {
            if (_eventsList != null && _eventsList.Any())
            {
                string name = _name;

                foreach (InputEvent action in _eventsList)
                {
                    TestInputEvent ta = ((TestInputEvent)action);
                    name += "|" + ta.Name;
                }
                return name;
            }

            return _name;
        }
    }
}
