﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VariableStochasticLearningAutomaton.Agent.Interfaces;
using System.Reflection;
using System.Collections.Concurrent;
using System.Configuration;
using System.Xml.Linq;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class EventStamp
    {
        public EventStamp( InputEvent ev) 
        {
            TimeStamp = DateTime.Now ; 
            Event = ev; 
        }

        public InputEvent Event { get; set; }
        public DateTime TimeStamp { get; set; }
    }


    public class InputEventManager
    {
        private static List<InputEventManager> _sListManagers = new List<InputEventManager>(); 

        static InputEventManager()
        {
            GenerateManagers(); 
        }

        public static InputEventManager GetInputEventManager(string session, string robot)
        {
            InputEventManager manager = _sListManagers.FirstOrDefault(s => s._session == session && s._robot == robot); 

            if ( manager == null)
            {
                manager = new InputEventManager(session, robot);
                _sListManagers.Add(manager); 
            }

            return manager; 
        }

        public static void GenerateManagers ()
        {
            if (_sListManagers.Any() == false)
            {
                string xmlpath = ConfigurationManager.AppSettings["EventManagersXmlPath"];
                XDocument doc = XDocument.Load(xmlpath);
                var managers = doc.Root.Descendants("EventManager");

                foreach (XElement xmanager in managers)
                {
                    InputEventManager manager = GetInputEventManager(GetAttribute(xmanager, "Session"), GetAttribute(xmanager, "Id"));
                    manager.Name = GetAttribute(xmanager, "Name");

                    manager.InitializeManager(xmanager);
                }
            }
        }

        public static string GetAttribute (XElement xel, string name)
        {
            string value = string.Empty;

            if (xel.Attribute(name) != null)
            {
                value = xel.Attribute(name).Value;
            }

            return value; 
        }

        private InputEventManager(string session, string robot)
        {
            _session = session;
            _robot = robot;
        }

        public string Name { get; set; }
        public string Id { get; set; }

        public string Description { get; set; }

        protected string _session;
        protected string _robot;

        protected InputEvent _currentEvent = null;
        public InputEvent GetCurrentEvent() { return _currentEvent; } 

        // set this to true if the motivation events are event that never tries a strategy 
        // ie, all events are the feedback - 
        // for instance, ball hits wall, ball hits paddle on table tennis

        public System.Threading.Mutex _mutex = new System.Threading.Mutex(); 

        #region InputEventList - history 
        protected List<EventStamp> _eventsHistory = new List<EventStamp>();
        public IEnumerable<EventStamp> GetEventsHistoryList()
        {
            return _eventsHistory;
        }

        int GetIntAttribute(XElement timeStep, string name )
        {
            int value = -1;
            int.TryParse(GetAttribute(timeStep, name), out value);

            return value; 
        }

        EventTriggerAction GetEventTriggerAttribute(XElement timeStep)
        {
            EventTriggerAction returnedValue = EventTriggerAction.Nothing;

            if (GetAttribute(timeStep, "Action").ToLower() == "replaceevent")
            {
                returnedValue = EventTriggerAction.ReplaceEvent;
            }
            else if (GetAttribute(timeStep, "Action").ToLower() == "addtoqueue")
            {
                returnedValue = EventTriggerAction.AddToQueue;
            }

            return returnedValue;
        }

        LogicOperator GetLogicOperatorAttribute(XElement timeStep)
        {
            LogicOperator returnedValue = LogicOperator.Or;
            

            if (GetAttribute(timeStep, "DoLogic").ToLower() == "or" || GetAttribute(timeStep, "Logic").ToLower() == "or")
            {
                returnedValue = LogicOperator.Or;
            }
            else if (GetAttribute(timeStep, "DoLogic").ToLower() == "and" || GetAttribute(timeStep, "Logic").ToLower() == "and")
            {
                returnedValue = LogicOperator.And;
            }

            return returnedValue;
        }

        LogicalEventOperator GenerateLogicEventOperator(IEnumerable<XElement> elements)
        {
            LogicalEventOperator logicOp = null;
            List<LogicalEventOperator> listOps = new List<LogicalEventOperator>(); 

            for ( int index = 0; index < elements.Count(); index ++)
            {
                var id1 = GetAttribute(elements.ElementAt(index), "Id");
                var e1 = _events.FirstOrDefault(s => s.Id == id1);
                var logop1 = GetLogicOperatorAttribute(elements.ElementAt(index));

                if (elements.Count() == 1)
                {
                    logicOp = new LogicalEventOperator(this, e1, logop1, null);
                    listOps.Add(logicOp);
                }

                if (index == 1)
                {
                    var id = GetAttribute(elements.ElementAt(0), "Id");
                    var e = _events.FirstOrDefault(s => s.Id == id);
                    var logop = GetLogicOperatorAttribute(elements.ElementAt(0));

                    logicOp = new LogicalEventOperator(this, e1, logop1, e);
                    listOps.Add(logicOp);
                }
                else if (index > 1)
                {
                    LogicalEventOperator lastOp = listOps[listOps.Count() - 1];
                    logicOp = new LogicalEventOperator(this, lastOp, logop1, e1 );
                    listOps.Add(logicOp);
                }
            }

            if (listOps.Count() > 0)
            {
                logicOp = listOps[listOps.Count() - 1];
            }

            return logicOp; 
        }


        #region FIDDLELISTS
        List<EventTrigger> _listEventTriggers = new List<EventTrigger>();
        public void InitializeManager(XElement manager)
        {
            _mutex.WaitOne();
            _actionBase.Add(new OutputAction(2000, "1"));
            _actionBase.Add(new OutputAction(2000, "2"));
            _actionBase.Add(new OutputAction(2000, "3"));
            _actionBase.Add(new OutputAction(2000, "4"));

            _actionBase.Add(new OutputAction(2000, "5"));
            _actionBase.Add(new OutputAction(2000, "6"));

            _actionBase.Add(new OutputAction(2000, "7"));
            _actionBase.Add(new OutputAction(2000, "8"));
            _actionBase.Add(new OutputAction(2000, "9"));


            // events 
            // 
            var events = manager.Descendants("Events");

            foreach(XElement ev in events.Descendants("Event"))
            {
                InputEvent input = new InputEvent(_actionBase, GetAttribute(ev, "Id"),
                    GetAttribute(ev, "IsMotivator").ToLower() == "true",
                    GetAttribute(ev, "IsFrameBoundary").ToLower() == "true",
                    GetAttribute(ev, "DoesSystemRespond").ToLower() == "true");

                input.Name = GetAttribute(ev, "Name");

                string motivator = GetAttribute(ev, "Motivator");
                if (motivator.ToLower() == "true")
                    input.Motivator = true;
                if (motivator.ToLower() == "false")
                    input.Motivator = false;

                _events.Add(input);

                List<Step> listSteps = new List<Step>();
                // any EventTriggers?
                foreach (XElement et in ev.Descendants("TriggerEvents"))
                {
                    var timers = et.Descendants("Time");
                    foreach (XElement timeStep in timers)
                    {
                        var timerEventChildren = et.Descendants("TriggerEvent");
                        LogicalEventOperator eventOperator2 = GenerateLogicEventOperator(timerEventChildren);

                        Step step = new Step(GetIntAttribute(timeStep, "Length"),
                            GetAttribute(timeStep, "DoLogic").ToLower() == "while",
                            eventOperator2,
                            GetEventTriggerAttribute(et));

                        listSteps.Add(step); 
                    }

                    if (timers.Any())
                        continue; 

                    var triggerEventChildren = et.Descendants("TriggerEvent");
                    LogicalEventOperator eventOperator = GenerateLogicEventOperator(triggerEventChildren);


                    listSteps.Add(new Step(eventOperator, GetEventTriggerAttribute(et)));
                }

                if( listSteps.Any())
                {
                    EventTrigger trigger = new EventTrigger(listSteps[listSteps.Count() - 1].Action, input);
                    _listEventTriggers.Add(trigger);
                    trigger.Steps = listSteps;
                }
            }

            //// old code, keep for now...
            //InputEvent leftLimitSwitch = new InputEvent(_actionBase, "1", false, true, true);
            //InputEvent rightLimitSwitch = new InputEvent(_actionBase, "2", false, true, true);
            //// InputEvent startEvent = new ARStartFrameEvent(_actionBase, false, true, false);
            //InputEvent noEventEvent = new InputEvent(_actionBase, "3", true, true, false, false);
            //InputEvent limitSwitchEventAfterGivenStrategy = new InputEvent(_actionBase, "4", true, true, false, true);


            ////_events.Add(startEvent);
            //_events.Add(leftLimitSwitch);
            //_events.Add(rightLimitSwitch);
            //_events.Add(noEventEvent);
            //_events.Add(limitSwitchEventAfterGivenStrategy);

            //LogicalEventOperator oneortwo = new LogicalEventOperator(this, leftLimitSwitch, LogicOperator.Or, rightLimitSwitch);
            //Step step11 = new Step(oneortwo, EventTriggerAction.Nothing);
            //// before timer is done...
            //Step step21 = new Step(10000, true, oneortwo, EventTriggerAction.ReplaceEvent);
            //EventTrigger trigger1 = new EventTrigger(EventTriggerAction.ReplaceEvent, noEventEvent);

            //trigger1.Steps.Add(step11);
            //trigger1.Steps.Add(step21);

            //// wait five seconds and then kick event
            //LogicalEventOperator oneortwo2 = new LogicalEventOperator(this, leftLimitSwitch, LogicOperator.Or, rightLimitSwitch);
            //Step step12 = new Step(oneortwo2, EventTriggerAction.Nothing);
            //// after timer is done
            //Step step22 = new Step(10000, false, null, EventTriggerAction.Nothing);
            //EventTrigger trigger2 = new EventTrigger(EventTriggerAction.AddToQueue, limitSwitchEventAfterGivenStrategy);

            //trigger2.Steps.Add(step12);
            //trigger2.Steps.Add(step22);

            //_listEventTriggers.Add(trigger1);
            //_listEventTriggers.Add(trigger2);


            _mutex.ReleaseMutex(); 
        }

        public InputEvent FiddleList(InputEvent ev)
        {
            // add start frame for first event that comes through
            //if (_eventsInterimHistory.Count() == 1 &&
            //    (_eventsInterimHistory[0].Event.GetType().Name.Contains("InputEvent") == true && timerValue == DateTime.MinValue))
            //{
            //    timerValue = DateTime.Now.AddMilliseconds(10000);
            //}

            return ev;
        }


        DateTime timerValue = DateTime.MinValue;
        public void PrePendingEventsFiddleList()
        {
            _mutex.WaitOne(); 
            
            for (int index = 0; index < _listEventTriggers.Count; index ++)
            {
                EventTrigger trigger = _listEventTriggers[index];
                if (trigger.RunLogic() == true)
                {
                    
                    if (trigger.Action == EventTriggerAction.ReplaceEvent && _listPendingEvents.Any())
                    {
                        if (_listPendingEvents[0].Store == "interimhistory" && _listPendingEvents[0].Operation == "add")
                        {
                            _listPendingEvents[0].Object = new EventStamp(trigger.Event);
                        }
                    }
                    else if (trigger.Action == EventTriggerAction.AddToQueue)
                        _listPendingEvents.Add(new PendingEvent() { Object = new EventStamp(trigger.Event), Store = "interimhistory", Operation = "add" });

                    if (trigger.Event.Motivator != null)
                    {
                        // AddMotivation(new MotivationTimer(0, null, _events[3], false, 1, 0, false));
                        AddMotivation(new MotivationTimer(InputEventManager.GetInputEventManager("default", "robot"), 0, null, trigger.Event, (bool)trigger.Event.Motivator, 1, 0, false));
                        Result((bool)trigger.Event.Motivator);
                    }
                }
            }

            _mutex.ReleaseMutex(); 
        }
        #endregion

        public void AddInputEventHistoryList(InputEvent ev)
        {
            _eventsHistory.Add(new EventStamp(ev));
        }

        #endregion

        #region InputEventList - interim history - most recent
        protected List<EventStamp> _eventsInterimHistory = new List<EventStamp>();
        public IEnumerable<EventStamp> GetEventsInterimHistoryList()
        {
            return _eventsInterimHistory;
        }

        protected List<PendingEvent> _listPendingEvents = new List<PendingEvent>();

        public void AddInputEventInterimHistory(InputEvent ev)
        {
            EventStamp stamp = new EventStamp(ev);

            _mutex.WaitOne();

            _listPendingEvents.Add (new PendingEvent()
            {
                Store = "interimhistory",
                Operation = "add",
                Object = stamp
            });

            _mutex.ReleaseMutex(); 
        }

        public void RemoveInputEventInterimHistory(InputEvent ev)
        {
            _mutex.WaitOne();
            var stamp = _eventsInterimHistory.FirstOrDefault(s => s.Event == ev);

            _listPendingEvents.Add(new PendingEvent()
            {
                Store = "interimhistory",
                Operation = "remove",
                Object = stamp
            });

            _mutex.ReleaseMutex();
            // _eventsInterimHistory.Remove (stamp);
        }

/*        public void MoveEventsToHistory()
        {
            _eventsHistory.Enqueue(_eventsInterimHistory.ToArray());
            _eventsInterimHistory.Clear();
        }
*/
        #endregion
        
        //#endregion
        #region InputEventList methods - added in at beginning of program

        protected List<InputEvent> _events = new List<InputEvent>();
        public IEnumerable<InputEvent> GetEventsList()
        {
            return _events.ToArray();
        }

        public InputEvent FindEventMatch (InputEvent ev)
        {
            _mutex.WaitOne(); 
            InputEvent returned = null; 
            foreach(InputEvent evTest in _events)
            {
                if (evTest.IsMatch(ev))
                {
                    returned = evTest;
                    break; 
                }
            }
            _mutex.ReleaseMutex(); 
            return returned; 
        }

        public void ResetEventTriggers()
        {
            _mutex.WaitOne();
            foreach (EventTrigger trigger in _listEventTriggers)
            {
                trigger.Reset();
            }
            _mutex.ReleaseMutex();
        }

        public bool CheckEventIsPending(string id)
        {
            bool isPending = false;

            if (_listPendingEvents.Any() == true)
            {
                _mutex.WaitOne();

                foreach (PendingEvent pending in _listPendingEvents)
                {
                    if (pending.Store == "interimhistory" && pending.Operation == "add"
                        && ((EventStamp)pending.Object).Event.Id == id)
                    {
                        isPending = true;
                        break;
                    }
                }

                _mutex.ReleaseMutex();
            }

            return isPending;
        }


        public bool CheckEventIsPending(InputEvent ev)
        {
            return CheckEventIsPending(ev.Id);
        }

        public void AddInputEvent(InputEvent ev)
        {
            _mutex.WaitOne();

            InputEvent test = FindEventMatch(ev);
            
            if (test == null)
            {
                _listPendingEvents.Add(new PendingEvent()
                {
                    Store = "events",
                    Operation = "add",
                    Object = ev
                });
            }

            if (test != null)
                ev = test; 

            _listPendingEvents.Add(new PendingEvent()
            {
                Store = "interimhistory",
                Operation = "add",
                Object = new EventStamp(ev)
            });

            _mutex.ReleaseMutex();
      }
        

        public void RemoveInputEvent(InputEvent ev)
        {
            _mutex.WaitOne();
            _listPendingEvents.Add(new PendingEvent()
            {
                Store = "events",
                Operation = "remove",
                Object = ev
            });
            _mutex.ReleaseMutex();

            // _events.Remove(ev);
        }

        #endregion end InputEventList methods

        protected List<OutputAction> _actionBase = new List<OutputAction>();
        public void AddOutputAction(OutputAction action)
        {
            _mutex.WaitOne();
            _listPendingEvents.Add(new PendingEvent()
            {
                Store = "actionBase",
                Operation = "add",
                Object = action
            });
            _mutex.ReleaseMutex();
        }

        public IEnumerable<OutputAction> GetOutputActions()
        {
            return _actionBase;
        }

        private List<OutputAction> _derivedActionList = new List<OutputAction>();

        public List<List<OutputAction>> GetDerivedList(int depth)
        {
            List<List<OutputAction>> list = new List<List<OutputAction>>();

            foreach (OutputAction action in _actionBase)
            {
                List<OutputAction> internalList = new List<OutputAction>();
                internalList.Add(action);
                list.Add(internalList);
            }

            for (int index = 1; index < depth; index++)
            {
                GetNextLevel(ref list, index); 
            }

            return list ; 
        }

        private void GetNextLevel( ref List<List<OutputAction>> list, int depth) 
        {
            List<List<OutputAction>> collector = new List<List<OutputAction>>(); 
            foreach (OutputAction action in _actionBase)
            {
                foreach (List<OutputAction> listActions in list)
                {
                    if ( listActions.Count() == depth)
                    {
                    List<OutputAction> internalList = new List<OutputAction>(listActions);
                       
                        internalList.Add(action) ;
                        collector.Add(internalList); 
                    }
                }
            }

            list.AddRange(collector); 
        }

    
        #region motivations maintenance 
        protected List<IMotivation> _motivationsList = new List<IMotivation>();

        public IEnumerable<IMotivation> Motivations
        {
            get { return _motivationsList; }
            private set { } 
        }

        public bool AddMotivation(IMotivation motivation)
        {
            _mutex.WaitOne();
            _listPendingEvents.Add(new PendingEvent()
            {
                Store = "motivation",
                Operation = "add",
                Object = motivation
            });
            _mutex.ReleaseMutex();

            //if (_motivationsList.Contains(motivation) == false)
            //{
            //    _motivationsList.Add(motivation);
            //    return true;
            //}

            return false; 
        }

        public bool RemoveMotivation(IMotivation motivation)
        {
            _mutex.WaitOne();
            _listPendingEvents.Add(new PendingEvent()
            {
                Store = "motivation",
                Operation = "remove",
                Object = motivation
            });
            _mutex.ReleaseMutex();
            //if (_motivationsList.Contains(motivation) == true)
            //{
            //    _motivationsList.Remove(motivation);
            //    return true;
            //}


            return false;
        }

        private bool _motivationEventOccurred = false; 
        /// <summary>
        /// returns null if during a wait period, false if no event occurs, true if event occurs
        /// </summary>
        /// <returns></returns>
        public MotivationResult CheckMotivations()
        {
            MotivationResult success = null;
            foreach (IMotivation motivation in _motivationsList) 
            {
                success = motivation.CheckIfMotivationEventOccurs();

                if (success != null)
                {
                    LastMotivation = motivation; 
                    _motivationEventOccurred = true; 
                    break;
                }
            }

            return success; 
        }

        public IMotivation LastMotivation { get; set; }

        #endregion end motivation interface 
        private int _eventInterimHistoryNumber = 0;
        // commented out 
        // bool skipNewEventCheck = false ; 
        protected bool CheckForNewEvents(bool changeNoFlags = false)
        {
            bool eventAddedToEventsList = false;
            bool notARepeater = false; 

            // we got a change in event number, process if it is repeater 
            // if it is a complex
            //if (_eventsInterimHistory.Any() == true && skipNewEventCheck == false && _eventInterimHistoryNumber != _eventsInterimHistory.Count())
            if (_eventsInterimHistory.Any() == true && _eventInterimHistoryNumber != _eventsInterimHistory.Count())
            {
                if (changeNoFlags == false)
                    _eventInterimHistoryNumber = _eventsInterimHistory.Count();

                if (_eventsInterimHistory.Count() == 1)
                    notARepeater = true;
                else
                {
                    InputEvent lastEvent = _eventsInterimHistory.ElementAt(_eventsInterimHistory.Count - 1).Event;
                    InputEvent lastEvent2 = _eventsInterimHistory.ElementAt(_eventsInterimHistory.Count - 2).Event;

                    // check time stamps if within 250 ms ignore it
                    if ((_eventsInterimHistory.ElementAt(_eventsInterimHistory.Count - 1).TimeStamp.Subtract(_eventsInterimHistory.ElementAt(_eventsInterimHistory.Count - 2).TimeStamp) <= new TimeSpan(0, 0, 0, 0, 250)) == true)
                    {
                        if (lastEvent.IsSimilar(lastEvent2))
                            notARepeater = false;
                        else
                            notARepeater = true;
                    }
                    else
                        notARepeater = true; 
                }
            }

            if (notARepeater == true)
                eventAddedToEventsList = true;

            // commented out 
            //if (skipNewEventCheck == true)
            //    skipNewEventCheck = false; 

            return eventAddedToEventsList; 
        }

        private bool IsInputAMotivator(InputEvent ev)
        {
            bool returnValue = false;

            foreach (IMotivation motive in _motivationsList)
            {
                MotivationResult result = motive.GetMotivationResult();
                if (result.Input == ev)
                {
                    returnValue = true;
                    break; 
                }
            }

            return returnValue; 
        }

        /// <summary>
        /// method finds matching event pattern
        /// </summary>
        /// <param name="eventPattern"></param>
        /// <returns></returns>
        private InputEventParent FindMatchingEventPatternObject(IEnumerable<InputEvent> eventPattern)
        {
            InputEventParent parent = null; 

            foreach (InputEvent ev in _events)
            {
                if (ev.GetEvents() != null)
                {
                    // if same length, COULD be match
                    if (ev.GetEvents().Count() == eventPattern.Count())
                    {
                        IEnumerator<InputEvent> complexEventEnumerator = ev.GetEvents().GetEnumerator();
                        IEnumerator<InputEvent> eventPatternEnumerator = eventPattern.GetEnumerator();

                        bool match100 = true;

                        for (int index = 0; index < eventPattern.Count(); index++)
                        {

                            complexEventEnumerator.MoveNext();
                            eventPatternEnumerator.MoveNext();

                            if (complexEventEnumerator.Current != eventPatternEnumerator.Current)
                            {
                                match100 = false;
                                break;
                            }
                        }

                        if (match100 == true)
                        {
                            parent = (InputEventParent)ev;
                            break;
                        }
                    }
                }
            }

            return parent;
        }


        MotivationResult FindMotivationResultByInputEvent(InputEvent ev)
        {
            MotivationResult favorable = null;
            foreach (IMotivation motivation in _motivationsList)
            {
                MotivationResult result = motivation.GetMotivationResult();

                if (ev == result.Input)
                {
                    favorable = result;
                    break;
                }
            }

            return favorable; 
        }

        public InputEvent GetCurrentEventWithStrategy ()
        {
            return _eventWithCurrentStrategy;
        }

        int _motivationEventsDepth = 2;
        InputEvent _eventWithCurrentStrategy = null;
        int _lastCurrentEventNumber = 0;

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool Run()
        {
            while (true)
            {
                _mutex.WaitOne();
                ProcessPendingEvents();
                InputEvent ev  = FiddleList(_currentEvent);
                bool eventAddedToEventsList = CheckForNewEvents();

                // if anything added to list, figure out what is the event that will be picked from
                if (eventAddedToEventsList == true)
                {
                    _currentEvent = _eventsInterimHistory[_lastCurrentEventNumber ++].Event;

                    if (_currentEvent.DoesSystemRespondToEvent == true)
                    {
                        if (_eventWithCurrentStrategy != null)
                        {
                            MotivationResult favorable = FindMotivationResultByInputEvent(_currentEvent);

                            if (favorable != null)
                            {
                                _eventWithCurrentStrategy.ChangeProbabilitiesFromInput(favorable);
                                Percentage(_eventWithCurrentStrategy.GetAction().Id, _eventWithCurrentStrategy);
                            }

                            _eventWithCurrentStrategy.FullyResetEvent();
                            _eventWithCurrentStrategy = null; 
                        }

                        // extract what will be the event to try a strategy...
                        if (_eventsInterimHistory.Count() > 1)
                            _eventWithCurrentStrategy = FindEventToRespondWithCurrentStrategy();
                        
                        // no event is a motivator so just use the starting frame event if available...maybe multiple events were put in the queue
                        if (_eventWithCurrentStrategy == null)
                        {
                            if (_eventsInterimHistory[0].Event.DoesSystemRespondToEvent == true && _eventsInterimHistory[0].Event.IsSetFrameBoundaryEvent == true)
                                _eventWithCurrentStrategy = _eventsInterimHistory[0].Event;
                            else
                                throw new Exception("No motivating events in queue and no starting frame event that the system can respond to either");
                        }

                        // if a frame boundary and the first event or not a frame boundary, find new strategy as response to event and run it...
                        // if ((_eventWithCurrentStrategy.IsSetFrameBoundaryEvent == true && _eventsInterimHistory.Count() == 1) || _eventWithCurrentStrategy.IsSetFrameBoundaryEvent == false)
                        if (_eventWithCurrentStrategy.GetAction() == null)
                        {
                            _eventWithCurrentStrategy.SetAction(_eventWithCurrentStrategy.GetProbableAction());
                            _eventWithCurrentStrategy.GetAction().Run();
                            
                        }
                    }
                    // if event IsMotivator and a current strategy is in progress, assess success as long as it isn't a frameboundary
                    else if (_currentEvent.IsMotivator == true)
                    {
                        if (_eventWithCurrentStrategy != null)
                        {
                            MotivationResult favorable = FindMotivationResultByInputEvent(_currentEvent);

                            if (favorable != null)
                            {
                                _eventWithCurrentStrategy.ChangeProbabilitiesFromInput(favorable);
                                Percentage(_eventWithCurrentStrategy.GetAction().Id, _eventWithCurrentStrategy);
                            }
                        }
                    }
                }
                else
                {
                    if (_currentEvent != null)
                    {
                        _currentEvent = FiddleList(_currentEvent);

                        // if a framesetBoundary that is not the first one in the list..., move stuff to history and then clear interim list
                        if (_currentEvent.IsSetFrameBoundaryEvent && _eventsInterimHistory.Count() > 1)
                        {
                            _eventsHistory.AddRange(_eventsInterimHistory);
                            _eventsInterimHistory.Clear();
                            _eventInterimHistoryNumber = 0;
                            _lastCurrentEventNumber = 0;
                            _eventWithCurrentStrategy.FullyResetEvent();
                            _eventWithCurrentStrategy = null;

                            ResetEventTriggers(); 
                        }

                        if (_eventWithCurrentStrategy != null && _eventWithCurrentStrategy.GetAction() != null)
                        {
                            if (_eventWithCurrentStrategy.GetAction().IsDone() == false)
                                _eventWithCurrentStrategy.GetAction().Run();
                        }

                    }
                }
                _mutex.ReleaseMutex();
            }

            return true; 
        }

        /// <summary>
        /// method finds last motivator and using _motivationEventsDepth
        /// decides if it has this event pattern already and returns that if it is available
        /// </summary>
        /// <returns></returns>
        InputEvent FindEventToRespondWithCurrentStrategy()
        {
            InputEvent motivationalEvent = null;
            
            for (int index = _eventsInterimHistory.Count() - 1; index >= 0 ; index--)
            {
                if (_eventsInterimHistory[index].Event.IsMotivator == true)
                {
                    InputEvent temp = _eventsInterimHistory[index].Event; 
                    if (_motivationEventsDepth > 1)
                    {
                        List<InputEvent> listMotivation = new List<InputEvent>();
                        
                        for(int counter = _motivationEventsDepth; counter > 0; counter -- )
                        {
                            listMotivation.Insert(0,_eventsInterimHistory[index].Event);

                            if (index > 0)
                                index--;
                            else
                                break; 
                        }

                        // find pattern match...if it exists
                        motivationalEvent = FindMatchingEventPatternObject(listMotivation);

                        // if no match for the pattern
                        if (motivationalEvent == null)
                        {
                            InputEventParent parent = new InputEventParent(this._actionBase);

                            parent.IsMotivator = temp.IsMotivator;
                            parent.IsSetFrameBoundaryEvent = temp.IsSetFrameBoundaryEvent;
                            parent.DoesSystemRespondToEvent = temp.DoesSystemRespondToEvent;
                            parent.SetEventsList(listMotivation);
                            motivationalEvent = parent;
                            _events.Add(parent);

                            // make id unique..for new event...
                            string newId = string.Empty; 

                            for(int eventId  = 0; eventId < listMotivation.Count(); eventId++)
                            {
                                if (eventId == 0)
                                    newId += listMotivation[0].Id;
                                else
                                    newId += "|" + listMotivation[0].Id;
                            }
                            parent.Id = newId; 

                            bool motivationFound = false; 
                            foreach(IMotivation motive in _motivationsList)
                            {
                                MotivationResult result = motive.GetMotivationResult();

                                if(result.Input == temp)
                                {
                                    MotivationTimer motivation = new MotivationTimer(InputEventManager.GetInputEventManager("default","robot"), 
                                        400000, null, parent, motive.TriggeredResult, result.Weight, 0, false);
                                    _motivationsList.Add(motivation);
                                    motivationFound = true; 
                                    break; 
                                }
                            }

                            //if (motivationFound == false)
                            //    throw new Exception("The InputEvent was marked as a motivator, but there is no corresponding motivator in the motivations list...");
                        }
                    }
                    else 
                        motivationalEvent = _eventsInterimHistory[index].Event;
                    break; 
                }
            }

            return motivationalEvent; 
        }


        private bool ProcessPendingEvents()
        {
            _mutex.WaitOne();

            PrePendingEventsFiddleList();

            bool newEvent = false;
            List<int> listValuesToRemove = new List<int>();
            int index = 0;

            foreach (PendingEvent pending in _listPendingEvents)
            {
                if (pending != null)
                {
                    if (pending != null && pending.Operation.ToLower() == "add")
                    {
                        if (pending.Object != null)
                        {
                            // will only add one on each cycle through...
                            if (pending.Store.ToLower() == "interimhistory" && newEvent == false)
                            {
                                _eventsInterimHistory.Add((EventStamp)pending.Object);

                                listValuesToRemove.Add(index);
                                newEvent = true;
                            }
                            else if (pending.Store.ToLower() == "events")
                            {
                                _events.Add((InputEvent)pending.Object);
                                listValuesToRemove.Add(index); 
                            }
                            else if (pending.Store.ToLower() == "motivation")
                            {
                                _motivationsList.Add((IMotivation)pending.Object);
                                listValuesToRemove.Add(index);
                            }
                            else if (pending.Store.ToLower() == "actionbase")
                            {
                                _actionBase.Add((OutputAction)pending.Object);
                                listValuesToRemove.Add(index);
                            }
                        }
                    }
                    else if (pending.Operation.ToLower() == "remove")
                    {
                        if (pending.Object != null)
                        {
                            if (pending.Store.ToLower() == "interimhistory")
                            {
                                _eventsInterimHistory.Remove((EventStamp)pending.Object);
                                listValuesToRemove.Add(index);
                            }
                            else if (pending.Store.ToLower() == "events")
                            {
                                _listPendingEvents.RemoveAt(index);
                                listValuesToRemove.Add(index);
                            }
                            else if (pending.Store.ToLower() == "motivations")
                            {
                                _motivationsList.Remove((IMotivation)pending.Object);
                                listValuesToRemove.Add(index);
                            }
                            else if (pending.Store.ToLower() == "actionbase")
                            {
                                _actionBase.Remove((OutputAction)pending.Object);
                                listValuesToRemove.Add(index);
                            }
                        }
                    }
                }
                index++;
            }

            for (int index2 = listValuesToRemove.Count() -1 ; index2 >= 0; index2 --)
            {
                int value = listValuesToRemove[index2];
                _listPendingEvents.RemoveAt(value);
            }

            _mutex.ReleaseMutex();
            return newEvent; 
        }

        private void CallSetValue(InputEvent ev, bool value = false)
        {
            object[] parameter = new object[] { value };
            MethodInfo mi2 = ev.GetType().GetMethod("SetValue");

            if (mi2 != null)
                mi2.Invoke(ev, parameter);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ev"></param>
        /// <returns></returns>
        bool DoesComplexEventExist(InputEvent ev)
        {
            bool match = true;
            IEnumerable<InputEvent> outerEvents = ev.GetEvents();

            // if is a complex event or has only one event (it isn't complex then!)
            if (outerEvents == null && ev.GetEventCount() == 0 || ev.GetEventCount() == 1)
            {
                return true;
            }

            foreach (InputEvent evEvent in outerEvents)
            {
                IEnumerable<InputEvent> testEvents = evEvent.GetEvents();
                if (testEvents != null && testEvents.Count() != outerEvents.Count())
                {
                    match = true;
                    for (int index = 0; index < ev.GetEventCount(); index++)
                    {
                        if (outerEvents.ElementAt(index) != testEvents.ElementAt(index))
                        {
                            match = false;
                            break;
                        }
                    }

                    if (match == true)
                        break;
                }
                else
                    match = false; 
            }

            return match; 
        }

        InputEvent FindLastMotivationEventInList(IEnumerable<EventStamp> listStamps)
        {
            InputEvent returnValue = null;

            for( int index = listStamps.Count() -1; index >= 0; index --)
            {
                EventStamp stamp = listStamps.ElementAt(index);
                foreach (InputEvent motivationEvent in MotivationTimer.MotivationEvents)
                {
                    if (motivationEvent == stamp.Event)
                    {
                        returnValue = stamp.Event;
                        break; 
                    }
                }

                if (returnValue != null)
                    break; 
            }

            return returnValue; 
        }

        /// <summary>
        /// method walks list and finds last event to try a scenario
        /// </summary>
        /// <param name="ev"></param>
        /// <returns></returns>
        InputEvent FindEventToReward(InputEvent ev)
        {
            InputEvent returnEvent = ev;

            if (returnEvent.GetAction() == null)
            {
                for ( int index = _eventsInterimHistory.Count() - 1; index >= 0 ; index --)
                {
                    if (_eventsInterimHistory[index].Event == ev)
                    {
                        if (index > 0)
                        {
                            returnEvent = _eventsInterimHistory[index - 1].Event;
                            if (returnEvent.GetAction() != null)
                                break;
                        }
                    }
                }
            }
            return returnEvent; 
        }

        int _maxEventStartDepth = 2;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputEvent"></param>
        /// <returns></returns>
        private bool? RespondToEvent(InputEvent inputEvent)
        {
            inputEvent = FiddleList(inputEvent);

            bool? returnValue = null;
            bool isMotivationEvent = false;

            // if event is not a motivation event (a motivation event can't be the first in _eventsInterimHistory list).
            if (_eventsInterimHistory.Any() && _eventsInterimHistory[0].Event != inputEvent && IsInputAMotivator(inputEvent) == true)
                isMotivationEvent = true;

            if (inputEvent.GetAction() == null && isMotivationEvent == false)
            {
                inputEvent.SetAction(inputEvent.GetProbableAction());
                return null;
            }

            // test, original here...
            //        if ((isMotivationEvent == false && inputEvent.GetAction().IsDone() == false) ||
            //// if motivating event is first event, let it run with a strategy to try -- we will look for second motivating event
            //(isMotivationEvent == true && inputEvent.GetAction().IsDone() == false && _eventsInterimHistory.Count() == 1))
            // change use of Motivation to be an event that will signal whether it is true or false
            if (isMotivationEvent == false && inputEvent.GetAction().IsDone() == false)
            {
                inputEvent.GetAction().Run();
            }
            else
            {
                MotivationResult favorable = null; 
                if (_eventsInterimHistory.Count() > 1)
                {
                    
                    foreach (IMotivation motivation in _motivationsList)
                    {
                        MotivationResult result = motivation.GetMotivationResult(); 

                        if (inputEvent == result.Input)
                        {
                            favorable = result; 
                            break; 
                        }
                    }
                }

                // an end of a frame is a motivation event -- other events if finished are ignored
                if (favorable != null) 
                {
                    returnValue = favorable.Result;

                    // finds last event to try a scenario...
                    // inputEvent = FindEventToReward(inputEvent);

                    // do we have a complex event that is only a partial pattern match to the simple events that have occurred?  
                    // if so, remove from list since won't be used
                    int maximumComplexEventSize = 3;
                    if (_eventsInterimHistory.Count() > 3)
                        _eventsInterimHistory.RemoveRange(0, _eventsInterimHistory.Count() - 3);

                    EventStamp[] eventStamps = _eventsInterimHistory.ToArray();
                    List<EventStamp> listStamps = new List<EventStamp>(eventStamps);

                    // remove the motivator event that got us into this loop, will add it back later
                    listStamps.RemoveAt(listStamps.Count() - 1);
                    
                    var simpleEvents = listStamps.Where(s => s.Event.GetEventCount() == 0);

                    EventStamp complexStamp = listStamps.FirstOrDefault(e => e.Event.GetEventCount() != 0);
                    int complexCount = listStamps.Where(e => e.Event.GetEventCount() != 0).Count();

                    if (complexCount > 1)
                        throw new Exception("InputEventManager::RespondToEvent - there are two complex events in _eventsInterimHistory collection");

                    // if a complex event and only thing in collection after removing motivator
                    if (complexStamp != null && listStamps.Count() == 1)
                    {
                        complexStamp.Event.ChangeProbabilitiesFromInput(favorable);
                        Console.WriteLine("complex event action response- " + favorable.Result);
                    }
                    // if a complex event and then ran into other simple events that didn't have a match...build the match now
                    else if (complexStamp != null && simpleEvents.Count() > 0)
                    {
                        List<InputEvent> list = new List<InputEvent>(complexStamp.Event.GetEvents());

                        foreach(EventStamp stamp in listStamps)
                        {
                            if (stamp != complexStamp )
                            {
                                list.Add(stamp.Event);
                            }
                        }
                        
                        InputEvent ev = new InputEventParent(this._actionBase);
                        ev.SetEventsList(list);
                        
                        //keep previous timestamp...might be minutes or even hours later
                        complexStamp.Event = ev; 
                        listStamps.Clear();
                        listStamps.Add(complexStamp);
                    }
                    // only one simple event from list, all complex events should be removed...
                    // otherwise a complex event we haven't seen before needs to be added to list
                    else if (simpleEvents.Count() == 1) // complexStamp should be null if this is true
                    {
                        EventStamp simpleStamp = listStamps.FirstOrDefault(e => e.Event.GetEventCount() == 0);
                        simpleStamp.Event.ChangeProbabilitiesFromInput(favorable);
                        Console.WriteLine("simple event action response - " + favorable.Result);
                    }
                    // if here, just create a parent and add the simple events to it
                    // don't do anything with it otherwise
                    else if (simpleEvents.Count() > 1)
                    {
                        // for the pattern that is to be saved, only keep a motivational event if it is the first event
                        InputEvent ev = new InputEventParent(this._actionBase);
                        int index = 0; 
                        foreach (EventStamp stamp in simpleEvents)
                        {
                            if (index != 0 && MotivationTimer.MotivationEvents.Contains(stamp.Event) == true)
                                continue;
                            index++;

                            if (stamp.Event.GetAction() != null)
                                stamp.Event.ResetEvent(); 

                            ev.AddEvent(stamp.Event);
                        }

                        listStamps.Clear();
                        listStamps.Add(new EventStamp(ev));

                        _mutex.WaitOne();
                        _events.Add(ev);
                        _mutex.ReleaseMutex(); 
                    }

                    // TODO: delete this next bit of code -debugging purposes only
                    foreach(EventStamp stamp in listStamps)
                    {
                        if (stamp.Event.GetEvents() != null && stamp.Event.GetEvents().Count() == 1)
                            break; 
                    }

                    // if no motivation event in the queue, add the event that got us here to queue
                    if (isMotivationEvent == true)
                        listStamps.Add(new EventStamp(inputEvent));

                    // ok, put what is left back into list
                    _eventsInterimHistory = new List<EventStamp>(listStamps);
                }
            }

            return returnValue;
        }

        private void ReconcileEventsList()
        {


        }

        object _callback = null;
        public void ResultCallback(object obj)
        {
            _callback = obj;
        }

        public void Percentage (string id, InputEvent ev)
        {
            Type type = _callback.GetType();
            MethodInfo mis = type.GetMethod("Percentage");

            string value = ev.Engine.GetActionPercent(id).ToString(); 

            object[] parameters = { value };
            mis.Invoke(_callback, parameters);

        }

        public void Result(bool value)
        {
            Type type = _callback.GetType();
            MethodInfo mis = type.GetMethod("Result");
            object[] parameters = { value };
            mis.Invoke(_callback, parameters);
        }

        public double GetEventActionPercentage(InputEvent ev, string actionId)
        {
            return ev.Engine.GetActionPercent(actionId);
        }
    }

    public class PendingEvent
    {
        public string Operation { get; set;  }
        public string Store { get; set; }
        public object Object { get; set; }
    }
}
