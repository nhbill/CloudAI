﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VariableStochasticLearningAutomaton.Agent
{
    public abstract class OutputActionTimed : OutputAction
    {
        // user generated, should return false unless ready to complete the action, then return true
        // at end of time if user logic isn't true, it returns true automatically
        public abstract bool DoTimedLogic();

        protected DateTime _timeEnd;
        private int _milliseconds;

        public OutputActionTimed(int milliseconds, string id) : base (id)
        {
            _milliseconds = milliseconds;
        }

        public override bool OnStart()
        {
            _timeEnd = DateTime.Now.AddMilliseconds(_milliseconds);
            return true; 
        }
        
        /// <summary>
        /// returns false if we are going to continue processing, ie not done yet
        /// when done with logic, return true
        /// </summary>
        /// <returns></returns>
        public override bool RunLogic()
        {
            // user generated, should return false unless ready to complete the action, then return true
            // at end of time if user logic isn't true, it returns true automatically
            bool logicResponse = DoTimedLogic();

            //if (logicResponse == true)
            //    return true;

            if (DateTime.Now <= _timeEnd && logicResponse == false)
                return false;
            else
                return true;
        }
    }
}
