﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariableStochasticLearningAutomaton.Agent
{
    
    public class Step
    {

        private LogicalEventOperator _logicalEventOperator = null;
        private DateTime _timer = DateTime.MinValue;
        private int _milliseconds = 0; 
        bool _checkLogicBeforeTimerDone = false;

        public EventTriggerAction Action { get; set; }

        public bool Completed { get; set; }

        public Step(LogicalEventOperator logic, EventTriggerAction action)
        {
            Action = action;
            _logicalEventOperator = logic;
        }

        public void Start()
        {
            if (_timer != DateTime.MinValue)
                _timer = DateTime.Now.Add(new TimeSpan(0, 0, 0, 0, _milliseconds));
        }

        public Step(int milliseconds, bool checkLogicBeforeTimerDone, LogicalEventOperator logic, EventTriggerAction action)
        {
            _milliseconds = milliseconds;
            _timer = DateTime.Now.Add(new TimeSpan(0, 0, 0, 0, milliseconds));
            _checkLogicBeforeTimerDone = checkLogicBeforeTimerDone;
            _logicalEventOperator = logic;
            Action = action; 
        }

        public bool IfCompleted ()
        {
            // if looking for while timer is running...
            if (_timer != DateTime.MinValue && _timer <= DateTime.Now && _checkLogicBeforeTimerDone == false)
            {
                if (_logicalEventOperator != null)
                    Completed = _logicalEventOperator.RunLogic();
                else
                    Completed = true; 
            }
            else if (_timer != DateTime.MinValue && _timer >= DateTime.Now && _checkLogicBeforeTimerDone == false)
            {
                if (_logicalEventOperator != null)
                    Completed = _logicalEventOperator.RunLogic();
                else
                    Completed = false;
            }
            // if looking for after timer done running...
            else if (_timer != DateTime.MinValue && _timer >= DateTime.Now && _checkLogicBeforeTimerDone == true)
            {
                if (_logicalEventOperator != null)
                    Completed = _logicalEventOperator.RunLogic();
                else
                    Completed = false;
            }
            else if (_timer != DateTime.MinValue && _timer <= DateTime.Now && _checkLogicBeforeTimerDone == true)
            {
                if (_logicalEventOperator != null)
                    Completed = _logicalEventOperator.RunLogic();
                else
                    Completed = true;
            }
            else
            {
                if (_logicalEventOperator != null)
                    Completed = _logicalEventOperator.RunLogic();
                else
                    Completed = true;
            }

            return Completed; 
        }

        public void Reset ()
        {
            Completed = false; 
            if (_logicalEventOperator != null)
                _logicalEventOperator.Reset(); 
        }
    }
}
