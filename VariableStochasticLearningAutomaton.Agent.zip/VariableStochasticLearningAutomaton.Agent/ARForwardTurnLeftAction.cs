﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class ARForwardTurnLeftAction : OutputActionTimed
    {
        public ARForwardTurnLeftAction(int milliseconds, string id) 
         :base(milliseconds, id)
        {

        }

    }
}
