﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class InputEvent 
    {
        private bool _enabled ; 
	    private bool _isOccurring ; 
	    private bool _actionIsRandom ; 
	    private OutputAction  _action ; // if is null, does random
	    
        private ProbabilitiesEnginev2 _probabilitiesEngine;
        protected List<InputEvent> _eventsList = null;
        protected int _eventCount = -1;

        public InputEvent(IEnumerable<OutputAction> pActionList, string id, bool isMotivator = false, bool isSetFrameBoundaryEvent = false, bool doesSystemRespondToEvent = false, bool? motivator = null) // calls BuildProbabilitiesMap
        {
	        _enabled = false ; 
	        _isOccurring = false ; 
	        _actionIsRandom = true ;

            if (pActionList != null)
                _probabilitiesEngine = new ProbabilitiesEnginev2(pActionList, this);

            IsMotivator = isMotivator;
            IsSetFrameBoundaryEvent = isSetFrameBoundaryEvent;
            DoesSystemRespondToEvent = doesSystemRespondToEvent;
            Id = id;
            Motivator = motivator; 
        }

        public ProbabilitiesEnginev2 Engine {  get { return _probabilitiesEngine; } }

        public string Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public bool IsMatch(InputEvent ev)
        {
            if (ev.Id == this.Id)
            {
                return true;
            }

            return false;
        }

        bool _setValue = true;
        public void SetValue(bool value = false)
        {
            _setValue = value;
        }

        public bool RunLogic()
        {
            if (_setValue == false)
                return false;
            else
            {
                _setValue = false;
                return true;
            }
        }

        public bool IsSimilar(InputEvent ev)
        {
            if (this == ev)
                return true;
            else
                return false;
        }

        public void SendDebugInfo(string start, string end)
        {

        }


        public bool? Motivator { get; set;  }

        public bool IsMotivator { get; set; }

        public bool IsSetFrameBoundaryEvent { get; set; }

        public bool DoesSystemRespondToEvent { get; set; }


        #region event management stuff 

        public IEnumerable<InputEvent> GetEvents()
        {
            return _eventsList; 
        }

        public int GetEventPosition()
        {
            return _eventCount;
        }


        public int GetEventCount()
        {
            if (_eventsList == null)
                return 0;
            else
                return _eventsList.Count(); 
        }

        public InputEvent NextEvent()
        {
            if (_eventsList != null )
            {
                _eventCount++;

                if (_eventCount >= _eventsList.Count())
                {
                    _eventCount = -1; 
                    return null;
                }

                return _eventsList[_eventCount];
            }

            return null; 
        }

        public InputEvent GetFirstEvent()
        {
            if (_eventsList != null)
            {
                return _eventsList[0];
            }

            return null; 
        }

        public void SetEventsList(List<InputEvent> list)
        {
            _eventsList = list; 
        }

        public InputEvent GetCurrentEvent()
        {
            if (_eventsList != null && _eventCount != -1)
            {
                return _eventsList[_eventCount];
            }

            return null; 
        }

        public void AddEvent(InputEvent input)
        {
            if (_eventsList == null)
                _eventsList = new List<InputEvent>();

            if (_eventsList.Contains(input) == false)
            {
                _eventsList.Add(input);
            }
        }

        public InputEvent Clone()
        {
            return null;
        }

        #endregion 

        public bool RunAsSequence()
        {
            if (_eventsList != null && _eventCount < _eventsList.Count())
                return _eventsList[_eventCount].Run();
            else
                return false; 
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool Run() 
        {
            //// are we in multiple events?
            //InputEvent input = GetCurrentEvent();
            //if ( input != null )
            //    return input.RunAsSequence(); 

            // otherwise...
	        if ( _isOccurring == false ) 
	        {
		        _isOccurring = RunLogic() ; 

		        if ( _isOccurring == true ) 
		        {
                    
                    OnStart();
                    _action = GetProbableAction();
                    // changed this - function has changed
                    // return false;
                    return true; 
          
		        }
	        }
            //else
            //{
            //    //if (_action.IsDone() == false)
            //    //    _action.Run();

            //    //if (_action.IsDone() == true)
            //    //{
            //    //    OnComplete();
            //    //    bool? favorable = InputEventManager.CheckMotivations();

            //    //    if (favorable != null)
            //    //    {
            //    //        ChangeProbabilitiesFromInput((bool)favorable);
            //    //        return true;
            //    //    }
            //    //}
            //}
	        return false ; 
        }

        public void ChangeProbabilitiesFromInput(MotivationResult result)
        {
            if (DoesSystemRespondToEvent == true)
            {
                for (int index = 0; index < result.Weight; index++)
                {
                    _probabilitiesEngine.ChangeProbabilitiesFromInput(_action, (bool)result.Result);
                }
                _probabilitiesEngine.CalculateProbabilities();
            }
            else
                _probabilitiesEngine = null; 
        }

        public void FullyResetEvent()
        {
            ResetEvent();
            // only here after probabilities have been done, do we want to clean out the list
            _action = null;
        }

        /*
	
        bool RunLogic () = 0 ; 
        bool CheckIfActionIsFavorable( ) = 0 ; */
        public void OnComplete()  // default calls CheckIfActionIsFavorable()
        {
	
        }
        public void OnStart()  // default calls CheckIfActionIsFavorable()
        {
	
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public OutputAction GetAction()
        {
	        return _action ; 
        }

        public void SetAction( OutputAction pAction)  // can set to an action so doesn't do probabilities...
        {
	        _action = pAction ; 
	        _actionIsRandom = false ;

            // TODO:  delete when completed here...
            SendDebugInfo("", "");
        }

        public void ResetEvent()  
        {
	        _enabled = true ; 
	        _isOccurring = false ;

            if (_action != null)
            {
                _action.Reset();
               //  _action = null;
            }

            _eventCount = -1; 

            if (_eventsList != null)
            {
                foreach (InputEvent input in _eventsList)
                {
                    input.ResetEvent(); 
                }
            }

            _probabilitiesEngine.ResetActions();
        }

        public bool Enabled()  
        {
	        return _enabled ;
        }

        public bool IsOccurring()  
        {
	        return _isOccurring ;
        }

        public OutputAction GetProbableAction()
        {
            OutputAction action = _probabilitiesEngine.GetProbableAction();
            if (action.IsDone() || action.IsProcessing())
                action.Reset();

            return action; 
        }

    //void Show() 
    //{
    //    for ( int index = 0 ; index < _actionList->Count(); index ++)
    //    {
    //        cout << "numerator = " << *(_numerators+index) << " denominator=" << *(_ptrDenominators+index) << " probability="  << *(_ptrProbabilities +index) << endl ; 
    //    }
	
    //    cout << endl ; 
    //}
    }
}