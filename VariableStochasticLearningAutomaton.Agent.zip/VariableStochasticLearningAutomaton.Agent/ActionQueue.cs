﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VariableStochasticLearningAutomaton.Agent
{
    public class ActionQueue
    {
        public ActionQueue()
        {

        }

        private	List<OutputAction> _actions = new List<OutputAction>();
	
        public bool Run ()    // returns true if any actions aren't done, otherwise false
        {
	        bool results = false ; 
	        for ( int index = 0 ; index < _actions.Count() ; index ++ ) 
	        {
		        OutputAction pAction = _actions[index]; 
		
		        if ( pAction.IsDone() == true) 
			        continue ; 
		        else 
		        {
			        results = true ; 
			        pAction.Run() ; 
		        }
	        }

	        return results ; 
        }

        public void Add(OutputAction pAction ) 
        {
	        _actions.Add(pAction) ; 
        }

        public void ResetActions()  // sets all actions to no processing and not done
        {
	        for ( int index = 0 ; index < _actions.Count() ; index ++ ) 
	        {
		        OutputAction pAction = _actions[index] ; 
		        pAction.Reset() ; 
	        }
        }
    }
}
