﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using VariableStochasticLearningAutomaton.Agent;

namespace VSLARestInterface.Controllers
{
    public class EventController : ApiController
    {

        private static DelegateCommand _thread = null;
        private delegate void DelegateCommand();



        InputEventManager _manager = InputEventManager.GetInputEventManager("default", "robot");

        public EventController()
        {
            if (_thread == null)
            {
                _thread = new DelegateCommand(this.DelegateCommandImpl);
                IAsyncResult result = _thread.BeginInvoke(DelegateCommandCallback, null);
            }
        }

        public void Percentage(string value)
        {
            var hub = GlobalHost.ConnectionManager.GetHubContext<MyHub1>();
            hub.Clients.All.Percentage(value);
        }

        public void Result (bool value)
        {
            var hub = GlobalHost.ConnectionManager.GetHubContext<MyHub1>();
            hub.Clients..All.Result(value);
        }

        private void DelegateCommandImpl()
        {
            _manager.ResultCallback(new EventController());
            _manager.Run();
        }

        private void DelegateCommandCallback(IAsyncResult result)
        {
            if (result.AsyncWaitHandle != null)
            {
                result.AsyncWaitHandle.Close();
            }
        }

        // GET: api/Event
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Event/5
        public string Get(int id)
        {
            string returnValue = "9999"; 
            // available events
            // 0 = left limit switch
            // 1 - right limiit switch 
            // 2 - no event event
            InputEvent ev = null; 
            if (id == 2)
                ev = new InputEvent(null, "2");
            else if (id ==1)
                ev = new InputEvent(null, "1");
            else if (id==3)
                ev = new InputEvent(null, "3");

            if (ev != null)
            {
                ev = _manager.FindEventMatch(ev);
                OutputAction currentAction = ev.GetAction();
                DateTime now = DateTime.Now.AddMilliseconds(1000);

                _manager.AddInputEvent(ev);

                OutputAction action = null;

                while (action == null)
                {
                    if (_manager.GetCurrentEventWithStrategy() != null && _manager.GetCurrentEventWithStrategy().GetAction() != null)
                        action = _manager.GetCurrentEventWithStrategy().GetAction();

                    if (now <= DateTime.Now)
                        break; 
                }

                if (action != null)
                {
                    returnValue = action.Id; 
                }
            }

            var hub = GlobalHost.ConnectionManager.GetHubContext<MyHub1>();
            hub.Clients.All.EventShow(id, int.Parse(returnValue));

            return returnValue; 
        }

        // POST: api/Event
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Event/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Event/5
        public void Delete(int id)
        {
        }
    }
}
