﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;

namespace VSLARestInterface
{
    public class MyHub1 : Hub
    {
        public void EventShow(int eventNumber, int strategy)
        {
            Clients.All.Event(eventNumber, strategy);
        }

        public void Result ( bool result)
        {
            Clients.All.Result(result);
        }

        public void Percentage(string result)
        {
            Clients.All.Percentage(result);
        }

    }
}