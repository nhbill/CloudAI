﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VariableStochasticLearningAutomaton.Agent;

namespace Pingpong
{
    public class PingPongEventManager : InputEventManager
    {
        public override void PrePendingEventsFiddleList()
        {

        }

        public override void InitializeManager()
        {

        }

        public override InputEvent FiddleList(InputEvent ev)
        {
            InputEvent returnValue = ev;

            //// if any change, reformulate the list...
            //if (changedList == true)
            //    _eventsInterimHistory = new List<EventStamp>(listStamps);

            // if have in first position a ball hit....replace with
            if (_eventsInterimHistory.Any() == true && _eventsInterimHistory[0].Event.GetType().Name.Contains("CollisionPongBaseEvent"))
            {
                if (((CollisionPongBaseEvent)_eventsInterimHistory[0].Event).Name.StartsWith("Ball Hit") == true)
                {
                    _eventsInterimHistory.RemoveAt(0);
                    if (_eventsInterimHistory.Any())
                    {
                        returnValue = _eventsInterimHistory[_eventsInterimHistory.Count() - 1].Event;
                        _currentEvent = returnValue;
                    }
                }
            }

            // look for 2 in a row of same event - remove last one
            for (int index = _eventsInterimHistory.Count() - 1; index >= 0; index--)
            {
                CheckIfNextIsMatchAndRemoveIfItIs(index, "Start Game");
                CheckIfNextIsMatchAndRemoveIfItIs(index, "Ball Hit Right Wall");
                CheckIfNextIsMatchAndRemoveIfItIs(index, "Ball Hit Left Wall");
                CheckIfNextIsMatchAndRemoveIfItIs(index, "Ball Collision Down");
                CheckIfNextIsMatchAndRemoveIfItIs(index, "Ball Collision Up");
                CheckIfNextIsMatchAndRemoveIfItIs(index, "Player Paddle Collision");
                CheckIfNextIsMatchAndRemoveIfItIs(index, "Enemy Paddle Collision");
            }

            // if a Start Game not in first position, remove it and then add the event to pending queue so gets added later...
            for (int index = _eventsInterimHistory.Count() - 1; index >= 0; index--)
            {
                if (index == 0)
                    continue;
                else
                {
                    if (_eventsInterimHistory[index].Event.GetType().Name.Contains("CollisionPongBaseEvent") == true && (((CollisionPongBaseEvent)_eventsInterimHistory[index].Event).Name.StartsWith("Start Game")))
                    {
                        AddInputEvent(_eventsInterimHistory[index].Event);
                        _eventsInterimHistory.RemoveAt(index);
                    }
                }
            }

            if (_eventsInterimHistory.Count() == 1 && 
                (_eventsInterimHistory[0].Event.GetType().Name.Contains("CollisionPongBaseEvent") == true &&
                ((CollisionPongBaseEvent)_eventsInterimHistory[0].Event).Name.StartsWith("Start Game") == false))
            {
                EventStamp stamp = _eventsInterimHistory[0];
                _eventsInterimHistory.RemoveAt(0);
                // add start event...
                AddInputEvent(_events[0]);
                AddInputEvent(stamp.Event);
            }

            //returnValue = _eventsInterimHistory[_eventsInterimHistory.Count() - 1].Event;

            return returnValue;
        }

        void CheckIfNextIsMatchAndRemoveIfItIs(int index, string name)
        {
            if (_eventsInterimHistory.Count() >= 2 && _eventsInterimHistory.Count() > index && index > 0)
            {
                if (_eventsInterimHistory[index - 1].Event.GetType().Name.Contains("CollisionPongBaseEvent") == true 
                    && ((CollisionPongBaseEvent)_eventsInterimHistory[index - 1].Event).Name.StartsWith(name) 
                    && _eventsInterimHistory[index].Event.GetType().Name.Contains("CollisionPongBaseEvent") == true
                    && ((CollisionPongBaseEvent)_eventsInterimHistory[index].Event).Name.StartsWith(name))
                {
                    _eventsInterimHistory.RemoveAt(index-1);
                }
            }
        }

    }
}
