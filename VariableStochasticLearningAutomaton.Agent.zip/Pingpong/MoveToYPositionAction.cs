﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VariableStochasticLearningAutomaton.Agent;

namespace Pingpong
{
    public class MoveToYPositionAction : OutputAction
    {
        public static Form1 Form { get; set; }

        public MoveToYPositionAction( int yPos)
        {
            X = 3;
            Y = yPos; 
        }

        public int Y { get; set; }
        public int X { get; set; }

        bool _setValue = false;
        public void SetValue(bool value = false)
        {
            _setValue = value;
        }

        static bool showDebugInfo = false; 

        public override bool RunLogic ()
        {
            bool returnValue = false; 

            int yP1 = Form.GetPlayerOneYPosition();

            if (yP1 > this.Y)
            {
                Form.StartPlayerOneMovingUp(this.Y);
                //Console.WriteLine("RunLogic:  moving Up to " + this.Y + " from " + yP1);
                returnValue = true;
            }
            else if (yP1 < this.Y)
            {
                Form.StartPlayerOneMovingDown(this.Y);
                //Console.WriteLine("RunLogic:  moving Down to " + this.Y + " from " + yP1);
                returnValue = true;
            }
            else
            {
                //if (showDebugInfo == true)
                //    Console.WriteLine("done moving to " + this.Y);
                Form.StopPlayerMoving();
            }
            return returnValue;  
        }
    }
}
