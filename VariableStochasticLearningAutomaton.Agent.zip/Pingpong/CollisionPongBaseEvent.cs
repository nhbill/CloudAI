﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VariableStochasticLearningAutomaton.Agent;

namespace Pingpong
{
    public class CollisionPongBaseEvent : InputEvent
    {
        public CollisionPongBaseEvent(IEnumerable<OutputAction> pActionList) :
            base(pActionList)
        {
            BlockNumber = -1;
        }

        public override void SendDebugInfo(string start, string end)
        {
            Console.WriteLine("Object:" + start + Name + " X=" + X + " Y=" + Y + " BX=" + BX + " BY=" + BY + " " + end);
        }

        public string Name { get; set; }
        
        public override bool IsMatch(InputEvent ev)
        {
            if (ev.GetType() == typeof(CollisionPongBaseEvent))
            {
                // TODO:  include blocknumber later for this...
                if (((CollisionPongBaseEvent)ev).X == this.X && ((CollisionPongBaseEvent)ev).Y == this.Y && ((CollisionPongBaseEvent)ev).BX == BX && ((CollisionPongBaseEvent)ev).BY == BY && ((CollisionPongBaseEvent)ev).Name == Name)
                    return true;
                else
                    return false;
            }

            return false; 
        }
        bool _setValue = false;
        public void SetValue(bool value = false)
        {
            _setValue = value;
        }

        public override bool RunLogic()
        {
            if ( _setValue == false)
                return false;
            else
            {
                _setValue = false;
                return true; 
            }
        }

        public override bool IsSimilar(InputEvent ev)
        {
            if (this == ev)
                return true;
            else
                return false;
        }


        public int Y { get; set; }
        public int X { get; set; }

        public int BY { get; set; }
        public int BX { get; set; }

        public int BlockNumber { get; set; } 


    }
}
